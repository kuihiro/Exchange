################################################################
# Copyright (c) 2026 Honor Device Co., Ltd. All rights reserved.
#
# Hardware Engineering Dept.
# Display Platform Technologies Dept.
#
# Author: Ding Yue 00012140 <dingyue2@honor.com>
################################################################


import struct
import io
import math
from PIL import ImageCms
from typing import Dict, Any
from comm import *
from log import *


# def LOG_D(*args): log('DEBUG', *args)


##################################################
################# ICC Definition ################
##################################################

# Refer to spec of ICC.1:2022

# Profile header      - 128 bytes
# Tag count           - 4   bytes
# Tag table           - 12  bytes for each tag

# Tagged element data - Various sizes
ICC_PROFILE_HEADER_LEN = 128
ICC_PROFILE_TAG_COUNT_LEN = 4

# Tag signature - 4 bytes
# Offset to beginning of tag element - 4 bytes
# Size of tag data - 4bytes
ICC_PROFILE_TAG_TABLE_SIGNATURE_SIZE = 4
ICC_PROFILE_TAG_TABLE_OFFSET_SIZE = 4
ICC_PROFILE_TAG_TABLE_TAG_DATA_SIZE = 4
ICC_PROFILE_TAG_TABLE_ELEMENT_SIZE = (ICC_PROFILE_TAG_TABLE_SIGNATURE_SIZE +
                                      ICC_PROFILE_TAG_TABLE_OFFSET_SIZE +
                                      ICC_PROFILE_TAG_TABLE_TAG_DATA_SIZE)
ICC_PROFILE_PCS_XYZ_16BIT_ENCODE_DENOMINATOR = 0x10000

# ICC.1, Table 68 - parametricCurveType function type encoding

# 4 bytes for one parameter
parametricCurveType = {
    0x0000: {'field length': 4,  'parameters': 'g', 'note': ''},
    0x0001: {'field length': 12, 'parameters': 'g, a, b', 'note': 'CIE 122-1966[10]'},
    0x0002: {'field length': 16, 'parameters': 'g, a, b, c', 'note': 'IEC 61966-3'},
    0x0003: {'field length': 20, 'parameters': 'g, a, b, c, d', 'note': 'IEC 61966-2.1(sRGB)'},
    0x0004: {'field length': 28, 'parameters': 'g, a, b, c, d, e, f', 'note': ''},
}
parametricCurveTypeParams = {
    0x0000: {'parameters': [] * 1},
    0x0001: {'parameters': [] * 3},
    0x0002: {'parameters': [] * 4},
    0x0003: {'parameters': [2.399994, 0.947861, 0.052139, 0.077393, 0.040451]},
    0x0004: {'parameters': [2.399994, 0.947861, 0.052139, 0.077393, 0.040451, 0.000000, 0.000000]},
}

# ICC profile extended info definition
ICC_PROFILE_EXTENDED_GAMUT_SRGB_DEFAULT = 'sRGB-default'
ICC_PROFILE_EXTENDED_GAMUT_SRGB = 'sRGB'
ICC_PROFILE_EXTENDED_GAMUT_P3 = 'P3'
ICC_PROFILE_EXTENDED_GAMUT_BT2020 = 'BT2020'
ICC_PROFILE_EXTENDED_WHITE_POINT_D50 = 'D50'
ICC_PROFILE_EXTENDED_WHITE_POINT_D65 = 'D65'
ICC_PROFILE_EXTENDED_TRANSFER_FUNCTION_DEFAULT = 'sRGB'


##################################################
################ Class Definition ################
##################################################

# TRC definition
class IccTrcTag(object):

    def __init__(self):

        self.type_signature = None
        self.function_type = 0
        self.function_type_note = None
        self.parameters = []


# ICC cicp definition
class IccCicpTag(object):

    def __init__(self):

        self.color_primaries = None
        self.transfer_characteristics = None
        self.matrix_coefficient = None
        self.full_range_flag = None
        self.color_primaries_desc = None
        self.transfer_characteristics_desc = None
        self.matrix_coefficient_desc = None
        self.full_range_flag_desc = None


# ICC extended data definition
class IccProfileDataExtend(object):

    def __init__(self):

        self.profile_description = ''
        self.version = None
        self.red_primary = None
        self.green_primary = None
        self.blue_primary = None
        self.red_trc = IccTrcTag()
        self.green_trc = IccTrcTag()
        self.blue_trc = IccTrcTag()
        self.chromatic_adaptation = None
        self.media_white_point = None
        self.media_black_point = None
        self.media_white_point_temperature = None
        self.perceptual_rendering_intent_gamut = None
        self.gamut = None
        self.white_point = None
        self.transfer_function = None
        self.cicp = IccCicpTag()


# Icc operation definition
class Icc(object):

    def __init__(self):

        self.profile_bytes = []
        self.profile_header = {}
        self.profile_tag_table = {}
        self.profile_tag_count = 0


    def tuples_are_closed(self, tuple1, tuple2, rel_tol=1e-3, abs_tol=0.0):
        if len(tuple1) != len(tuple2):

            return False

        return all(math.isclose(a, b, rel_tol=rel_tol, abs_tol=abs_tol) for a, b in zip(tuple1, tuple2))

    def get_profile_tag_table(self) -> None:

        icc_profile_bytes = self.profile_bytes
        tag_count_offset = ICC_PROFILE_HEADER_LEN
        tag_count_data_size = ICC_PROFILE_TAG_COUNT_LEN
        tag_count, = struct.unpack('>I',
                                   icc_profile_bytes[tag_count_offset: tag_count_offset + tag_count_data_size])

        self.profile_tag_count = tag_count
        self.profile_tag_table['tag count'] = {'offset': tag_count_offset, 'data size': tag_count_data_size}

        tag_table_sig_offset = tag_count_offset + tag_count_data_size
        loop_ptr = tag_table_sig_offset

        for tag in range(0, tag_count):
            tag_signature, = struct.unpack('>I',  icc_profile_bytes[loop_ptr: loop_ptr + 4])
            tag_signature = tag_signature.to_bytes(4, 'big').decode()
            loop_ptr = loop_ptr + 4
            tag_offset, = struct.unpack('>I',  icc_profile_bytes[loop_ptr: loop_ptr + 4])
            loop_ptr = loop_ptr + 4
            tag_data_size, = struct.unpack('>I',  icc_profile_bytes[loop_ptr: loop_ptr + 4])
            loop_ptr = loop_ptr + 4
            self.profile_tag_table[tag_signature] = {'offset': tag_offset, 'data size': tag_data_size}


    def s15Fixed16NumberToFloat(self, s15Fixed16Number: int) -> float:

        s15Fixed16Number_float = round(s15Fixed16Number / ICC_PROFILE_PCS_XYZ_16BIT_ENCODE_DENOMINATOR, 6)

        return s15Fixed16Number_float


    def get_profile_trc_tag_data(self, trc_tag: str) -> IccTrcTag:

        trc_tag_offset = self.profile_tag_table[trc_tag]['offset']
        trc_data_size = self.profile_tag_table[trc_tag]['data size']
        trc_bin = self.profile_bytes[trc_tag_offset: trc_tag_offset + trc_data_size]

        trc = IccTrcTag()

        # byte 0~3 - tag signature
        type_signature, = struct.unpack('>I', trc_bin[0: 4])
        type_signature = type_signature.to_bytes(4, 'big').decode()

        # byte 4~7 - reserved, shall be set to 0

        # byte 8~9 - encode value of the function type (uInt16Number)
        function_type, = struct.unpack('>H', trc_bin[8: 10])
        function_type_note = parametricCurveType[function_type]['note']

        # byte 10~11 - reserved

        # byte 12~end - one or more parameters (s15Fixed16Number)
        param_num = int(parametricCurveType[function_type]['field length'] / 4)

        for i in range(0, param_num):
            param_offset = 12 + i * 4
            param, = struct.unpack('>I', trc_bin[param_offset: param_offset + 4])
            param_float = self.s15Fixed16NumberToFloat(param)
            trc.parameters.append(param_float)
        trc.type_signature = type_signature
        trc.function_type = function_type
        trc.function_type_note = function_type_note

        return trc


    def get_profile_extended_description(self,
                                         icc_extended: IccProfileDataExtend) -> Dict[str, Any]:

        # Get gamut and white point description

        # Check chromatic adaption with 1e-3 relative tolerance
        if icc_extended is None:
            icc_profile_extended_description = {
                'gamut': 'sRGB',
                'white point': 'D50',
                'transfer function': 'sRGB',
                'chromatic adaption': 'D50 to D65'
            }

            return icc_profile_extended_description

        red_primary = icc_extended.red_primary
        green_primary = icc_extended.green_primary
        blue_primary = icc_extended.blue_primary
        media_white_point = icc_extended.media_white_point

        if red_primary is not None and green_primary is not None and blue_primary is not None:
            if (self.tuples_are_closed(red_primary[0], SRGB_GAMUT_RED_PRIMARIES_CIEXYZ) and
                self.tuples_are_closed(green_primary[0], SRGB_GAMUT_GREEN_PRIMARIES_CIEXYZ) and
                self.tuples_are_closed(blue_primary[0], SRGB_GAMUT_BLUE_PRIMARIES_CIEXYZ)):
                icc_extended.gamut = ICC_PROFILE_EXTENDED_GAMUT_SRGB
            elif (self.tuples_are_closed(red_primary[0], P3_GAMUT_RED_PRIMARIES_CIEXYZ) and
                  self.tuples_are_closed(green_primary[0], P3_GAMUT_GREEN_PRIMARIES_CIEXYZ) and
                  self.tuples_are_closed(blue_primary[0], P3_GAMUT_BLUE_PRIMARIES_CIEXYZ)):
                icc_extended.gamut = ICC_PROFILE_EXTENDED_GAMUT_P3
            else:
                icc_extended.gamut = ICC_PROFILE_EXTENDED_GAMUT_SRGB_DEFAULT

        if media_white_point is not None:
            if self.tuples_are_closed(media_white_point[0], WHITE_POINT_D50):
                icc_extended.white_point = ICC_PROFILE_EXTENDED_WHITE_POINT_D50
            elif self.tuples_are_closed(media_white_point[0], WHITE_POINT_D65):
                icc_extended.white_point = ICC_PROFILE_EXTENDED_WHITE_POINT_D65
            else:
                icc_extended.white_point = ICC_PROFILE_EXTENDED_WHITE_POINT_D50

        # Check transfer function

        # Check chromatic adaption with 1e-3 relative tolerance
        red_trc_function_type = icc_extended.red_trc.function_type
        red_trc_params = icc_extended.red_trc.parameters
        red_trc_params_expected = parametricCurveTypeParams[red_trc_function_type]['parameters']
        green_trc_function_type = icc_extended.green_trc.function_type
        green_trc_params = icc_extended.green_trc.parameters
        green_trc_params_expected = parametricCurveTypeParams[green_trc_function_type]['parameters']
        blue_trc_function_type = icc_extended.blue_trc.function_type
        blue_trc_params = icc_extended.blue_trc.parameters
        blue_trc_params_expected = parametricCurveTypeParams[blue_trc_function_type]['parameters']

        if ((red_trc_function_type == 3 and
             self.tuples_are_closed(red_trc_params, red_trc_params_expected, rel_tol=1e-4)) and
            (green_trc_function_type == 3 and
             self.tuples_are_closed(green_trc_params, green_trc_params_expected, rel_tol=1e-4)) and
            (blue_trc_function_type == 3 and
             self.tuples_are_closed(blue_trc_params, blue_trc_params_expected, rel_tol=1e-4))):
            transfer_function = 'sRGB'
        elif ((red_trc_function_type == 4 and
               self.tuples_are_closed(red_trc_params, red_trc_params_expected, rel_tol=1e-4)) and
              (green_trc_function_type == 4 and
               self.tuples_are_closed(green_trc_params, green_trc_params_expected, rel_tol=1e-4)) and
              (blue_trc_function_type == 4 and
               self.tuples_are_closed(blue_trc_params, blue_trc_params_expected, rel_tol=1e-4))):
            transfer_function = 'sRGB'
        else:
            transfer_function = ''

        gamut = icc_extended.gamut

        white_point = icc_extended.white_point

        # Chromatic adaption

        # Check chromatic adaption with 1e-2 relative tolerance
        if icc_extended.white_point == 'D50':
            if icc_extended.chromatic_adaptation is not None:
                if (self.tuples_are_closed(icc_extended.chromatic_adaptation[0][0],
                                        CHROMATIC_ADAPTION_D50_TO_D65[0], rel_tol=1e-2) and
                    (self.tuples_are_closed(icc_extended.chromatic_adaptation[0][1],
                                         CHROMATIC_ADAPTION_D50_TO_D65[1], rel_tol=1e-2)) and
                    (self.tuples_are_closed(icc_extended.chromatic_adaptation[0][2],
                                         CHROMATIC_ADAPTION_D50_TO_D65[2], rel_tol=1e-2))):
                    chromatic_adaption = 'D50 to D65'
                else:
                    chromatic_adaption = ''
            else:
                chromatic_adaption = ''
        elif icc_extended.white_point == 'D65':
            if icc_extended.chromatic_adaptation is not None:
                if (self.tuples_are_closed(icc_extended.chromatic_adaptation[0][0],
                                        CHROMATIC_ADAPTION_D50_TO_D65[0], rel_tol=1e-2) and
                    (self.tuples_are_closed(icc_extended.chromatic_adaptation[0][1],
                                         CHROMATIC_ADAPTION_D50_TO_D65[1], rel_tol=1e-2)) and
                    (self.tuples_are_closed(icc_extended.chromatic_adaptation[0][2],
                                         CHROMATIC_ADAPTION_D50_TO_D65[2], rel_tol=1e-2))):
                    chromatic_adaption = 'D50 to D65'
                else:
                    chromatic_adaption = ''
            else:
                chromatic_adaption = ''
        else:
            chromatic_adaption = ''

        icc_profile_extended_description = {
            'gamut': gamut,
            'white point': white_point,
            'transfer function': transfer_function,
            'chromatic adaption': chromatic_adaption
        }

        return icc_profile_extended_description


    def get_profile_data_extend(self, image_icc: bytes) -> IccProfileDataExtend | None:

        if not image_icc:

            return None

        icc_profile = ImageCms.ImageCmsProfile(io.BytesIO(image_icc))
        profile_data = IccProfileDataExtend()
        profile_data.profile_description = icc_profile.profile.profile_description
        profile_data.version = icc_profile.profile.version
        profile_data.red_primary = icc_profile.profile.red_primary
        profile_data.green_primary = icc_profile.profile.green_primary
        profile_data.blue_primary = icc_profile.profile.blue_primary
        profile_data.chromatic_adaptation = icc_profile.profile.chromatic_adaptation
        profile_data.media_white_point = icc_profile.profile.media_white_point
        profile_data.media_black_point = icc_profile.profile.media_black_point
        profile_data.media_white_point_temperature = icc_profile.profile.media_white_point_temperature
        profile_data.perceptual_rendering_intent_gamut = icc_profile.profile.perceptual_rendering_intent_gamut

        # Get other tags in profile table
        self.profile_bytes = image_icc
        self.get_profile_tag_table()

        # Get rTRC, gTRC and bTRC
        if 'rTRC' in self.profile_tag_table:
            rTRC_data = self.get_profile_trc_tag_data('rTRC')

            LOG_D("rTRC type signature:", rTRC_data.type_signature)
            LOG_D("rTRC type function encode value = %d, %s" %
                  (rTRC_data.function_type, rTRC_data.function_type_note))
            LOG_D("rTRC parameters number:", len(rTRC_data.parameters))
            LOG_D("rTRC parameters:", rTRC_data.parameters)

            profile_data.red_trc = rTRC_data
        if 'gTRC' in self.profile_tag_table:
            gTRC_data = self.get_profile_trc_tag_data('gTRC')

            LOG_D("gTRC type signature:",gTRC_data.type_signature)
            LOG_D("gTRC type function encode value = %d, %s" %
                  (gTRC_data.function_type, gTRC_data.function_type_note))
            LOG_D("gTRC parameters number:", len(gTRC_data.parameters))
            LOG_D("gTRC parameters:", gTRC_data.parameters)

            profile_data.green_trc = gTRC_data
        if 'bTRC' in self.profile_tag_table:
            bTRC_data = self.get_profile_trc_tag_data('bTRC')

            LOG_D("bTRC type signature:", bTRC_data.type_signature)
            LOG_D("bTRC type function encode value = %d, %s" %
                  (bTRC_data.function_type, bTRC_data.function_type_note))
            LOG_D("bTRC parameters number:", len(bTRC_data.parameters))
            LOG_D("bTRC parameters:", bTRC_data.parameters)

            profile_data.blue_trc = bTRC_data

        # Get cicp tag
        if 'cicp' in self.profile_tag_table:
            cicp_tag_offset = self.profile_tag_table['cicp']['offset']
            cicp_data_size = self.profile_tag_table['cicp']['data size']

            # cicp tag: byte 0~3 is 'cicp', byte 4~7 is reserved
            cicp_data_offset = cicp_tag_offset + 8
            cicp_data_len = cicp_data_size - 8
            cicp_data_bin = self.profile_bytes[cicp_data_offset: cicp_data_offset + cicp_data_len]
            cicp_data, = struct.unpack('>I', cicp_data_bin)

            # cicp tag - big endian
            # byte 8 - color primaries
            # byte 9 - transfer characteristics
            # byte 10 - matrix coefficient
            # byte 11 - full range
            profile_data.cicp.color_primaries = (cicp_data & 0xFF000000) >> 24
            profile_data.cicp.transfer_characteristics = (cicp_data & 0x00FF0000) >> 16
            profile_data.cicp.matrix_coefficient = (cicp_data & 0x0000FF00) >> 8
            profile_data.cicp.full_range_flag = (cicp_data & 0x000000FF)

            # Get cicp tag description
            profile_data.cicp.color_primaries_desc = \
                cicp_tag_color_primaries_mapping[profile_data.cicp.color_primaries]
            profile_data.cicp.transfer_characteristics_desc = \
                cicp_tag_transfer_characteristics_mapping[profile_data.cicp.transfer_characteristics]
            profile_data.cicp.matrix_coefficient_desc = \
                cicp_tag_matrix_coefficients_mapping[profile_data.cicp.matrix_coefficient]
            profile_data.cicp.full_range_flag_desc = \
                cicp_tag_full_range_flag_mapping[profile_data.cicp.full_range_flag]

            LOG_D("CICP: %s, %s, %s, %s" % (profile_data.cicp.color_primaries_desc,
                                            profile_data.cicp.transfer_characteristics_desc,
                                            profile_data.cicp.matrix_coefficient_desc,
                                            profile_data.cicp.full_range_flag_desc))
        else:
            icc_extended_desc = self.get_profile_extended_description(profile_data)

            # Get color primaries
            if icc_extended_desc['gamut'] == ICC_PROFILE_EXTENDED_GAMUT_SRGB:
                profile_data.cicp.color_primaries = CICP_COLOR_PRIMARIES_SRGB
            elif icc_extended_desc['gamut'] == ICC_PROFILE_EXTENDED_GAMUT_P3:
                profile_data.cicp.color_primaries = CICP_COLOR_PRIMARIES_P3
            elif icc_extended_desc['gamut'] == ICC_PROFILE_EXTENDED_GAMUT_BT2020:
                profile_data.cicp.color_primaries = CICP_COLOR_PRIMARIES_BT2020
            else:
                LOG_W('Invalid icc profile extended description of gamut, use sRGB as default!')
                profile_data.cicp.color_primaries = CICP_COLOR_PRIMARIES_SRGB

            # Get transfer function
            if icc_extended_desc['transfer function'] == 'sRGB':
                profile_data.cicp.transfer_characteristics = CICP_TRANSFER_CHARACTERISTICS_SRGB
            else:
                LOG_W('Invalid icc profile extended description of transfer function, use sRGB as default!')

            # Set matrix coefficient to identity as default
            profile_data.cicp.matrix_coefficient = CICP_MATRIX_COEFFICIENT_IDENTITY

            # Set full range as default
            profile_data.cicp.full_range_flag = CICP_FULL_RANGE

        return profile_data


if __name__ == "__main__":

    LOG_I('ICC module...')
