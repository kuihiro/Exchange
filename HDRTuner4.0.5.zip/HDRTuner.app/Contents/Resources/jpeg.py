################################################################
# Copyright (c) 2026 Honor Device Co., Ltd. All rights reserved.
#
# Hardware Engineering Dept.
# Display Platform Technologies Dept.
#
# Author: Ding Yue 00012140 <dingyue2@honor.com>
################################################################


import struct
import cv2
import piexif
import icc
import numpy as np
import gain_map_metadata as gmmd
from typing import List, Dict, Tuple, Any
from comm import *
from log import *


# def LOG_D(*args): log('DEBUG', *args)


##################################################
################# JPEG Definition ################
##################################################

# JPEG basic
JPEG_SOI_OFFSET = 0

# JPEG marker value
JPEG_SOI_MARKER  = 0xFFD8
JPEG_APP0_MARKER = 0xFFE0
JPEG_APP1_MARKER = 0xFFE1
JPEG_APP2_MARKER = 0xFFE2
JPEG_SOF0_MARKER = 0xFFC0
JPEG_SOF1_MARKER = 0xFFC2
JPEG_DFT_MARKER  = 0xFFC4
JPEG_DQT_MARKER  = 0xFFDB
JPEG_DRI_MARKER  = 0xFFDD
JPEG_SOS_MARKER  = 0xFFDA
JPEG_EOI_MARKER  = 0xFFD9

# JPEG marker mapping
jpeg_marker_mapping = {
    0xFFD8: "SOI[Start of Image]",
    0xFFE0: "APP0",
    0xFFE1: "APP1",
    0xFFE2: "APP2",
    0xFFC0: "SOF0[Start of Fame]",
    0xFFC2: "SOF0[Start of Fame]",
    0xFFC4: "DHT[Define Huffman Table]",
    0xFFDB: "DQT[Define Quantization Table]",
    0xFFDD: "DRI[Define Restart Interval]",
    0xFFDA: "SOS[Start of Scan]",
    0xFFD9: "EOI[End of Image]"
}

# JPEG APPn marker string
JPEG_APP0_JFIF_TAG = 'JFIF'
JPEG_APP1_EXIF_TAG = 'Exif'
JPEG_APP1_HTTP_TAG = 'http'
JPEG_APP1_XMP_TAG = 'http://ns.adobe.com/xap/1.0/\x00'
JPEG_APP2_MPF_TAG = 'MPF\00'
JPEG_APP2_ICC_TAG = 'ICC_'
JPEG_APP2_ICC_PROFILE_TAG = b'ICC_PROFILE\x00\x01\x01'


##################################################
################# EXIF Definition ################
##################################################

# EXIF tags
EXIF_TAG_IFD0_ORIENTATION = 0x0112
EXIF_TAG_IFD0_MAKE = 0x010F
EXIF_TAG_IFD0_MODEL = 0x0110
EXIF_TAG_IFD0_COLOR_SPACE = 0xA001

# EXIF mapping - orientation
exif_tag_orientation_mapping = {
    0x00: 'Undefined',
    0x01: 'Horizontal(normal)',
    0x02: 'Mirror horizontal',
    0x03: 'Rotate 180',
    0x04: 'Mirror vertical',
    0x05: 'Mirror horizontal and rotate 270 CW',
    0x06: 'Rotate 90 CW',
    0x07: 'Mirror horizontal and rotate 90 CW',
    0x08: 'Rotate 270 CW'
}

# EXIF mapping - color space
exif_tag_color_space_mapping = {
    0x0001: "sRGB",
    0x0002: "Adobe RGB",
    0xFFFD: "Wide Gamut RGB",
    0xFFFE: "ICC Profile",
    0xFFFF: "Uncalibrated"
}


##################################################
############### Gain Map Definition ##############
##################################################

# Refer to spec of ISO 21496-1:2025
ISO_SPEC_PATH = 'iso_21496-1'

# ISO 21496-1 jpeg marker
ISO_21496_1_URN_STR = 'urn:iso:std:iso:ts:21496:-1'
JPEG_APP2_GAIN_MAP_URN_SIZE = 28
JPEG_APP2_GAIN_MAP_URN = b'urn:iso:std:iso:ts:21496:-1\x00'
JPEG_APP2_GAIN_MAP_METADATA_SC_LENGTH = 0x5B
JPEG_APP2_GAIN_MAP_METADATA_MC_LENGTH = 0xAB

# ISO gain map urn format definition
GAIN_MAP_FORMAT_CSV = 'gain_map_format.csv'
GAIN_MAP_FORMAT_COL_OFFSET = 'Offset(Hex)'
GAIN_MAP_FORMAT_COL_VALUE = 'Value(Hex)'
GAIN_MAP_FORMAT_COL_DESCRIPTION = 'Description'
GAIN_MAP_FORMAT_VERSION_LENGTH_BYTE_COUNT = 0x24
GAIN_MAP_FORMAT_VERSION_APP2_DATA_LENGTH = \
(GAIN_MAP_FORMAT_VERSION_LENGTH_BYTE_COUNT - 2)

# Gain map metadata definition
GAIN_MAP_QUANTIZATION_JPEG = 8
GAIN_MAP_IS_MULTICHANNEL_BIT = 7
GAIN_MAP_USE_BASE_COLOUR_SPACE_BIT = 6
GAIN_MAP_IS_MULTICHANNEL_MASK = \
    (1 << GAIN_MAP_IS_MULTICHANNEL_BIT)
GAIN_MAP_USE_BASE_COLOUR_SPACE_MASK = \
    (1 << GAIN_MAP_USE_BASE_COLOUR_SPACE_BIT)

# Gain map channel info mapping
gain_map_channel_mapping = {
    0: 'monochrome gain map',
    1: 'multi-channel gain map'
}

# Gain map color space mapping
gain_map_colorimetry_mapping = {
    0: 'use alternate color space',
    1: 'use baseline color space'
}


##################################################
################# MPF Definition #################
##################################################

# Refer to spec of CIPA-DC-007:2025
mpf_marker_mapping = {
    0x00: "Undefined",
    0x03: "Baseline MP Primary Image",
    0x05: "ISO HDR Gain Map"
}
MPF_FORMAT_START = 0
MPF_FORMAT_ENDIAN_TAG_OFFSET = MPF_FORMAT_START + 8
MPF_FORMAT_BASELINE_IMAGE_SIZE_START = (MPF_FORMAT_START + 0x3E)
MPF_FORMAT_BASELINE_IMAGE_SIZE_LENGTH = 4
MPF_FORMAT_GAIN_MAP_IMAGE_SIZE_START = (MPF_FORMAT_START + 0x4E)
MPF_FORMAT_GAIN_MAP_IMAGE_SIZE_LENGTH = 4
MPF_FORMAT_GAIN_MAP_IMAGE_OFFSET_START = (MPF_FORMAT_START + 0x52)
MPF_FORMAT_GAIN_MAP_IMAGE_OFFSET_LENGTH = 4

# MPF template in hex string list
MPF_TEMPLATE_HEX_STRING = ['FF', 'E2', '0', '58', '4D', '50', '46', '0',
                           '4D', '4D', '0', '2A', '0', '0', '0', '8',
                           '0', '3', 'B0', '0', '0', '7', '0', '0',
                           '0', '4', '30', '31', '30', '30', 'B0', '1',
                           '0', '4', '0', '0', '0', '1', '0', '0',
                           '0', '2', 'B0', '2', '0', '7', '0', '0',
                           '0', '20', '0', '0', '0', '32', '0', '0',
                           '0', '0', '0', '3', '0', '0', '0', '0',
                           '0', '0', '0', '0', '0', '0', '0', '0',
                           '0', '0', '0', '5', '0', '0', '0', '0',
                           '0', '0', '0', '0', '0', '0', '0', '0',
                           '0', '0']


##################################################
################# XMP Definition #################
##################################################

# Refer to Ultra HDR V1.0
XMP_NS_ULTRA_HDR_GAIN_MAP = 'http://ns.adobe.com/hdr-gain-map/1.0/'


##################################################
################ Encoder Definition ##############
##################################################

# JPEG encoder return value
ENCODER_RET_SUCCESS = 0
ENCODER_RET_FAILURE = 1


##################################################
################ Class Definition ################
##################################################

# JPEG APPn definition
class JpegAppN(object):

    def __init__(self, app_n: str):

        self.app_n = app_n
        self.tag = ''
        self.offset = 0
        self.len = 0
        self.data = []
        self.private_data = []


# Gain map HDR image codec definition
class GainMapHdrCodec(object):

    def __init__(self):

        pass


    def get_format_prop(self, image_data: bytes) -> Dict:

        pt = 0
        image_size = 0
        last_app0_offset = 0
        last_app1_offset = 0
        jpeg_app_exif = JpegAppN('')
        jpeg_app_icc = JpegAppN('')
        jpeg_app_mpf = JpegAppN('')
        jpeg_app_iso_hdr = JpegAppN('')
        jpeg_app_ultra_hdr = JpegAppN('')

        while True:
            marker, = struct.unpack('>H', image_data[pt: pt + 2])
            # LOG_D(jpeg_marker_mapping.get(marker))
            image_size = image_size + 1
            if marker == JPEG_APP0_MARKER:
                app0_len, = struct.unpack('>H', image_data[pt + 2: pt + 2 + 2])
                last_app0_offset = pt + 2 + app0_len
            if marker == JPEG_APP1_MARKER:
                app1_len, = struct.unpack('>H', image_data[pt + 2: pt + 2 + 2])
                app1_tag = image_data[pt + 4: pt + 8].decode('ascii')
                if app1_tag == JPEG_APP1_HTTP_TAG:
                    app1_xmp_matched = image_data[pt + 2 + 2: pt + 2 + app1_len]
                    if JPEG_APP1_XMP_TAG.encode('utf-8') in app1_xmp_matched:
                        if XMP_NS_ULTRA_HDR_GAIN_MAP.encode('utf-8') in app1_xmp_matched:
                            jpeg_app_ultra_hdr = JpegAppN('APP1')
                            jpeg_app_ultra_hdr.tag = XMP_NS_ULTRA_HDR_GAIN_MAP
                            jpeg_app_ultra_hdr.offset = pt
                            jpeg_app_ultra_hdr.len = app1_len
                            jpeg_app_ultra_hdr.data = image_data[pt + 2 + 2: pt + 2 + app1_len]
                            last_app1_offset = pt + 2 + app1_len
                if app1_tag == JPEG_APP1_EXIF_TAG:
                    jpeg_app_exif = JpegAppN('APP1')
                    jpeg_app_exif.tag = 'Exif'
                    jpeg_app_exif.offset = pt
                    jpeg_app_exif.len = app1_len
                    jpeg_app_exif.data = image_data[pt + 2 + 2: pt + 2 + app1_len]
                    last_app1_offset = pt + 2 + app1_len
            if marker == JPEG_APP2_MARKER:
                app2_tag = image_data[pt + 4: pt + 8].decode('ascii')
                # Get MPF data
                if app2_tag == JPEG_APP2_MPF_TAG:
                    app2_len, = struct.unpack(">H", image_data[pt + 2: pt + 4])
                    jpeg_app_mpf = JpegAppN('APP2')
                    jpeg_app_mpf.tag = 'MPF'
                    jpeg_app_mpf.offset = pt
                    jpeg_app_mpf.len = app2_len
                    jpeg_app_mpf.data = image_data[pt + 2 + 2: pt + 2 + app2_len]
                # Get ICC profile data
                if app2_tag == JPEG_APP2_ICC_TAG:
                    app2_len, = struct.unpack('>H', image_data[pt + 2: pt + 2 + 2])
                    jpeg_app_icc = JpegAppN('APP2')
                    jpeg_app_icc.tag = 'ICC'
                    jpeg_app_icc.offset = pt
                    jpeg_app_icc.len = app2_len
                    # Note: ICC_PROFILE\x00 (12 bytes) + seq_no(1 byte) + count (1 byte) is not icc data
                    icc_chunk_bytes = 14
                    jpeg_app_icc.data = image_data[pt + 2 + 2 + icc_chunk_bytes: pt + 2 + app2_len]
                # Get iso gain map hdr metadata
                app2_gm_urn = image_data[pt + 2 + 2: pt + 2 + 2 + JPEG_APP2_GAIN_MAP_URN_SIZE]
                if app2_gm_urn == JPEG_APP2_GAIN_MAP_URN:
                    app2_len, = struct.unpack('>H', image_data[pt + 2: pt + 2 + 2])
                    jpeg_app_iso_hdr = JpegAppN('APP2')
                    jpeg_app_iso_hdr.tag = ISO_21496_1_URN_STR
                    jpeg_app_iso_hdr.offset = pt
                    jpeg_app_iso_hdr.len = app2_len
                    jpeg_app_iso_hdr.data = image_data[pt + 2 + 2: pt + 2 + app2_len]
                    # Skip iso 21496-1 urn, only save the gain map metadata
                    jpeg_app_iso_hdr.private_data = \
                        image_data[pt + 2 + 2 + len(app2_gm_urn): pt + 2 + app2_len]
            if marker == JPEG_SOI_MARKER:
                pt = pt + 2
            elif marker == JPEG_EOI_MARKER:
                # LOG_D("Image size:", hex(image_size))
                break
            elif marker == JPEG_SOS_MARKER:
                offset = 0
                while True:
                    marker, = struct.unpack(">H", image_data[pt + offset: pt + offset + 2])
                    if marker == JPEG_EOI_MARKER:
                        # LOG_D(jpeg_marker_mapping.get(marker))
                        image_size = pt + offset + 2
                        # LOG_D("Image size: ", hex(pt + offset + 2))
                        break
                    offset = offset + 1
                    if pt + offset + 2 > len(image_data):
                        # LOG_D("pt + offset + 2 > len(image_data)", pt + offset + 2)
                        break
                break
            elif marker == JPEG_EOI_MARKER:
                # LOG_D("Image size: ", hex(image_size))
                break
            else:
                len_chunk, = struct.unpack(">H", image_data[pt + 2: pt +4])
                image_size = image_size + len_chunk
                pt = pt + 2 + len_chunk
            if pt > len(image_data):
                # LOG_D("Image size: ", hex(image_size))
                break
        if last_app1_offset == 0:
            if last_app0_offset > 0:
                last_app1_offset = last_app0_offset
            elif last_app0_offset == 0:
                last_app1_offset = 2
            else:
                pass

        image_prop_dict = {
            'image_size': image_size,
            'last_app1_offset': last_app1_offset,
            'exif': jpeg_app_exif,
            'icc': jpeg_app_icc,
            'mpf': jpeg_app_mpf,
            'iso_hdr': jpeg_app_iso_hdr,
            'ultra_hdr': jpeg_app_ultra_hdr
        }
        # Show debug log
        # for key, value in image_prop_dict.items():
        #     if isinstance(value, JpegAppN):
        #         LOG_D(key, value.__dict__)
        #     else:
        #         LOG_D('%s = 0x%08x' % (key, value))

        return image_prop_dict


    def mpf_extractor(self, mpf_data: List[Any], mpf_data_offset: int) -> Dict:

        mpf_image_info_dict = {}

        if not mpf_data:
            mpf_image_info_dict = {'mpf_valid_flag': False}

            return mpf_image_info_dict
        if mpf_data[0x00] == 0x4D and mpf_data[0x01] == 0x50 and mpf_data[0x02] == 0x46:
            if mpf_data[0x04] == 0x4D and mpf_data[0x05] == 0x4D and \
                    mpf_data[0x06] == 0x00 and mpf_data[0x07] == 0x2A:
                mpf_endian_tag = 'big_endian'
            elif mpf_data[0x04] == 0x49 and mpf_data[0x05] == 0x49 and \
                    mpf_data[0x06] == 0x2A and mpf_data[0x07] == 0x00:
                mpf_endian_tag = 'little_endian'
            else:
                mpf_image_info_dict = {'mpf_valid_flag': False}

                return mpf_image_info_dict

            if mpf_endian_tag == 'big_endian':
                mpf_image_num = mpf_data[0x25]
            else:
                mpf_image_num = mpf_data[0x22]

            if mpf_image_num > 1:
                if mpf_endian_tag == 'big_endian':
                    individual_image_0_attr = mpf_data[0x38]
                    individual_image_0_size = (mpf_data[0x3A] << 24) + (mpf_data[0x3B] << 16) + \
                                              (mpf_data[0x3C] << 8) + mpf_data[0x3D]
                    individual_image_0_offset = (mpf_data[0x42] << 24) + (mpf_data[0x43] << 16) + \
                                                (mpf_data[0x44] << 8) + mpf_data[0x45]
                    individual_image_1_attr = mpf_data[0x47]
                    individual_image_1_size = (mpf_data[0x4A] << 24) + (mpf_data[0x4B] << 16) + \
                                              (mpf_data[0x4C] << 8) + mpf_data[0x4D]
                    individual_image_1_offset = (mpf_data[0x4E] << 24) + (mpf_data[0x4F] << 16) + \
                                                (mpf_data[0x50] << 8) + mpf_data[0x51]
                else:
                    individual_image_0_attr = mpf_data[0x38]
                    individual_image_0_size = (mpf_data[0x3D] << 24) + (mpf_data[0x3C] << 16) + \
                                              (mpf_data[0x3B] << 8) + mpf_data[0x3A]
                    individual_image_0_offset = (mpf_data[0x41] << 24) + (mpf_data[0x40] << 16) + \
                                                (mpf_data[0x3F] << 8) + mpf_data[0x3E]
                    individual_image_1_attr = mpf_data[0x48]
                    individual_image_1_size = (mpf_data[0x4D] << 24) + (mpf_data[0x4C] << 16) + \
                                              (mpf_data[0x4B] << 8) + mpf_data[0x4A]
                    individual_image_1_offset = (mpf_data[0x51] << 24) + (mpf_data[0x50] << 16) + \
                                                (mpf_data[0x4F] << 8) + mpf_data[0x4E]
            else:
                LOG_W("There is only one image in MPF")
                mpf_image_info_dict = {'mpf_valid_flag': True, 'mpf_image_num': 1}
                return mpf_image_info_dict

            mpf_image_info_dict = {'mpf_endian': mpf_endian_tag,
                                   'mpf_image_num': mpf_image_num,
                                   'mpf_valid_flag': True,
                                   'ind_image_0_attr': individual_image_0_attr,
                                   'ind_image_0_size': individual_image_0_size,
                                   'ind_image_0_offset': individual_image_0_offset,
                                   'ind_image_1_attr': individual_image_1_attr,
                                   'ind_image_1_size': individual_image_1_size,
                                   'ind_image_1_offset': individual_image_1_offset
                                   }

            if (individual_image_1_offset + mpf_data_offset + 0x08) != individual_image_0_size:
                LOG_E("Mpf error: size of 1st individual image doesn't match EOI offset")
                mpf_image_info_dict['mpf_valid_flag'] = False

            return mpf_image_info_dict
        else:
            return mpf_image_info_dict


    def mpf_encoder(self,
                    base_len: int,
                    base_app_offset: int,
                    app2_iso_len: int,
                    app2_icc_len: int,
                    gain_map_len: int) -> bytes:

        # Get MPF template
        mpf_data_hex_str = MPF_TEMPLATE_HEX_STRING
        mpf_data_int = []
        for item in mpf_data_hex_str:
            mpf_data_int.append(int(item, 16))
        mpf_bytes = struct.pack(str(len(mpf_data_int)) + 'B', *mpf_data_int)

        # Compute MPF metadata

        # Baseline MP primary image individual size
        # This field specifies the size of image data between SOI and EOI markers of an individual image.
        # The byte order depends on MP Endian.
        base_mp_primary_image_size = base_len + app2_iso_len + app2_icc_len+ len(mpf_bytes)
        LOG_D('Baseline MP primary image size = 0x%08x' % base_mp_primary_image_size)

        # Gain map MP individual image individual size
        # This field specifies the size of image data between SOI and EOI markers of an individual image.
        # The byte order depends on MP Endian.
        gain_map_individual_image_size = gain_map_len
        LOG_D('Gain map individual image size = 0x%08x' % gain_map_individual_image_size)

        # Gain map MP individual image offset
        # This field specifies the data offset to the beginning (i.e. SOI marker) of an individual image.
        # The byte order depends on MP Endian.
        # It equals to (MP primary image size - MPF data offset - 08h).
        # Offset 08h means excluding APP2 tag (2 bytes), APP2 length (2 bytes), 'MPF\x00' (4 bytes)
        # Notes:
        # JPEG APPn sequence: APP0 (JFIF), APP2 (ISO), APP2 (MPF), APP2 (ICC)
        # There are only APP0 (JFIF), APP2 (ISO) before APP2 (MPF)
        mpf_data_offset = base_app_offset + app2_iso_len
        gain_map_individual_image_offset = base_mp_primary_image_size - mpf_data_offset - 0x08
        LOG_D('Gain map individual image offset = 0x%08x' % gain_map_individual_image_offset)

        # Update MPF metadata
        mpf_bytes_array = bytearray(mpf_bytes)

        # Always use MPF big endian

        # Baseline MP primary image individual size, data offset from 0x3E to 0x41
        mpf_bytes_array[0x3E: 0x3E + 4] = struct.pack('>I', base_mp_primary_image_size)

        # Gain map MP individual image individual size, data offset from 0x4E to 0x51
        mpf_bytes_array[0x4E: 0x4E + 4] = struct.pack('>I', gain_map_individual_image_size)

        # Gain map MP individual image offset, data offset from 0x52 to 0x55
        mpf_bytes_array[0x52: 0x52 + 4] =struct.pack('>I', gain_map_individual_image_offset)

        mpf_bytes = bytes(mpf_bytes_array)

        return mpf_bytes


    def exif_extractor(self, image_exif: bytes) -> ExifInfo:

        # Get exif data
        if not image_exif:
            exif_info = ExifInfo()
        else:
            exif_data = piexif.load(image_exif)['0th']
            # Parse exif information of make, model and color space
            if exif_data and (EXIF_TAG_IFD0_MAKE in exif_data):
                exif_make = exif_data[EXIF_TAG_IFD0_MAKE].decode('ascii')
            else:
                exif_make = None
            if exif_data and (EXIF_TAG_IFD0_MODEL in exif_data):
                exif_model = exif_data[EXIF_TAG_IFD0_MODEL].decode('ascii')
            else:
                exif_model = None
            if exif_data and (EXIF_TAG_IFD0_COLOR_SPACE in exif_data):
                exif_color_space = exif_tag_color_space_mapping[exif_data[EXIF_TAG_IFD0_COLOR_SPACE]]
            else:
                exif_color_space = None
            # Get exif information orientation
            if exif_data and (EXIF_TAG_IFD0_ORIENTATION in exif_data):
                exif_tag_orientation = exif_data[EXIF_TAG_IFD0_ORIENTATION]
                exif_orientation = exif_tag_orientation_mapping[exif_tag_orientation]
                # cv2 rectify image orientation, so set exif_orientation_rectified to True
                exif_orientation_rectified = True
            else:
                exif_orientation = "Horizontal(normal)"
                exif_orientation_rectified = False
            # Return exif info
            exif_info = ExifInfo()
            exif_info.orientation = exif_orientation
            exif_info.orientation_rectified = exif_orientation_rectified
            exif_info.make = exif_make
            exif_info.model = exif_model
            exif_info.color_space = exif_color_space

        return exif_info


    def exif_tag_orientation_rectification(self,image_rgb: np.ndarray, orientation: str) -> Tuple[np.ndarray, bool]:

        # 'Undefined'
        # 'Horizontal(normal)'
        # 'Mirror horizontal'
        # 'Rotate 180'
        # 'Mirror vertical'
        # 'Mirror horizontal and rotate 270 CW'
        # 'Rotate 90 CW'
        # 'Mirror horizontal and rotate 90 CW'
        # 'Rotate 270 CW'
        if orientation == 'Horizontal(normal)':
            return image_rgb, False
        elif orientation == 'Rotate 90 CW':
            return cv2.rotate(image_rgb, cv2.ROTATE_90_CLOCKWISE), True
        else:
            if orientation:
                LOG_W('Cannot support orientation type of %s' % orientation)

            return image_rgb, False


    def base_image_decoder(self, base_image: bytes, base_info: Dict) -> BaselineImage:

        # Get baseline image rgb
        np_arr = np.frombuffer(base_image, np.uint8)
        base_image_bgr = cv2.imdecode(np_arr, cv2.IMREAD_COLOR)
        base_image_rgb = cv2.cvtColor(base_image_bgr, cv2.COLOR_BGR2RGB)

        # Get baseline image icc properties
        base_image_icc = base_info['icc'].data
        base_icc = icc.Icc()
        base_icc_extended = base_icc.get_profile_data_extend(base_image_icc)

        if base_icc_extended:
            cicp_color_primaries = base_icc_extended.cicp.color_primaries
            cicp_transfer_characteristics = base_icc_extended.cicp.transfer_characteristics
            cicp_matrix_coefficient = base_icc_extended.cicp.matrix_coefficient
            cicp_full_range_flag = base_icc_extended.cicp.full_range_flag
        else:
            cicp_color_primaries = None
            cicp_transfer_characteristics = None
            cicp_matrix_coefficient = None
            cicp_full_range_flag = None

        # Get baseline image exif properties
        base_image_exif = base_info['exif'].data
        base_exif_info = self.exif_extractor(base_image_exif)

        # Update decoded baseline image class
        base_image_decoded = BaselineImage()
        base_image_decoded.image_rgb = base_image_rgb
        base_image_decoded.prop.type = 'JPEG'
        base_image_decoded.prop.planes = 3
        base_image_decoded.prop.width = base_image_rgb.shape[1]
        base_image_decoded.prop.height = base_image_rgb.shape[0]
        base_image_decoded.prop.bit_depth = 8
        base_image_decoded.prop.data_type = 'uint8'
        base_image_decoded.prop.white_point = 'D50'
        base_image_decoded.prop.cicp.color_primaries = cicp_color_primaries
        base_image_decoded.prop.cicp.transfer_function = cicp_transfer_characteristics
        base_image_decoded.prop.cicp.matrix_coefficient = cicp_matrix_coefficient
        base_image_decoded.prop.cicp.full_range_flag = cicp_full_range_flag
        base_image_decoded.prop.icc_profile = base_icc_extended
        base_image_decoded.prop.icc_profile_bytes = base_image_icc
        base_image_decoded.prop.exif = base_exif_info

        return base_image_decoded


    def gain_map_decoder(self, gain_map: bytes, base_orientation: str) -> GainMap:

        # Get gain map info
        gain_map_info = self.get_format_prop(gain_map)

        # Extract gain map metadata
        # ISO 21496-1:2025
        if gain_map_info['iso_hdr'].tag == ISO_21496_1_URN_STR:
            gain_map_metadata_bin = gain_map_info['iso_hdr'].private_data
            gm_is_multichannel = (gain_map_metadata_bin[4] & GAIN_MAP_IS_MULTICHANNEL_MASK) \
                                 >> GAIN_MAP_IS_MULTICHANNEL_BIT
            # 3-channel gain map
            if gm_is_multichannel == 1:
                gain_map_metadata = gmmd.GainMapMetadataMc()
                gain_map_planes = 3
                np_arr = np.frombuffer(gain_map, np.uint8)
                gain_map_bgr = cv2.imdecode(np_arr, cv2.IMREAD_COLOR)
                gain_map_rgb = cv2.cvtColor(gain_map_bgr, cv2.COLOR_BGR2RGB)
            # Monochrome gain map
            else:
                gain_map_metadata = gmmd.GainMapMetadataSc()
                gain_map_planes = 1
                np_arr = np.frombuffer(gain_map, np.uint8)
                gain_map_bgr = cv2.imdecode(np_arr, cv2.IMREAD_COLOR)
                # Don't need to convert bgr to rgb for monochrome gain map
                gain_map_rgb = gain_map_bgr
            # Get gain map metadata parameters
            gain_map_metadata = gain_map_metadata.unpack(gain_map_metadata_bin)
            gain_map_metadata_params = gain_map_metadata.get_params()
        else:
            gain_map_rgb = None
            gain_map_planes = 1
            gain_map_metadata = None
            gain_map_metadata_params = None

        # Get gain map icc properties
        gain_map_icc = gain_map_info['icc'].data
        gm_icc = icc.Icc()
        gain_map_icc_extended = gm_icc.get_profile_data_extend(gain_map_icc)

        if gain_map_icc_extended:
            cicp_color_primaries = gain_map_icc_extended.cicp.color_primaries
            cicp_transfer_characteristics = gain_map_icc_extended.cicp.transfer_characteristics
            cicp_matrix_coefficient = gain_map_icc_extended.cicp.matrix_coefficient
            cicp_full_range_flag = gain_map_icc_extended.cicp.full_range_flag
        else:
            cicp_color_primaries = None
            cicp_transfer_characteristics = None
            cicp_matrix_coefficient = None
            cicp_full_range_flag = None

        # Get gain map exif properties
        gain_map_exif = gain_map_info['exif'].data
        gain_map_exif_info = self.exif_extractor(gain_map_exif)

        # Rotate gain map following the exif tag of orientation
        if gain_map_rgb is not None:
            gain_map_rgb, status = self.exif_tag_orientation_rectification(gain_map_rgb, base_orientation)
            gain_map_exif_info.orientation_rectified = status

        # Update decoded gain map class
        gain_map_decoded = GainMap()
        gain_map_decoded.image_rgb = gain_map_rgb
        gain_map_decoded.prop.type = 'JPEG'
        gain_map_decoded.prop.width = gain_map_rgb.shape[1]
        gain_map_decoded.prop.height = gain_map_rgb.shape[0]
        gain_map_decoded.prop.planes = gain_map_planes
        gain_map_decoded.prop.bit_depth = 8
        gain_map_decoded.prop.data_type = 'uint8'
        gain_map_decoded.prop.white_point = 'D50'
        gain_map_decoded.prop.cicp.color_primaries = cicp_color_primaries
        gain_map_decoded.prop.cicp.transfer_function = cicp_transfer_characteristics
        gain_map_decoded.prop.cicp.matrix_coefficient = cicp_matrix_coefficient
        gain_map_decoded.prop.cicp.full_range_flag = cicp_full_range_flag
        gain_map_decoded.prop.icc_profile = gain_map_icc_extended
        gain_map_decoded.prop.exif = gain_map_exif_info
        gain_map_decoded.metadata_payload = gain_map_metadata
        gain_map_decoded.metadata_param = gain_map_metadata_params

        return gain_map_decoded


    def decoder(self, gain_map_hdr_image_path: str) -> GainMapHdrImage | None:

        # Get image data
        try:
            with open(gain_map_hdr_image_path, 'rb') as fp_base:
                image_data = fp_base.read()
        except FileNotFoundError as e:
            LOG_E(f'Open gain map HDR image failed: {e}')

            return None

        # Get baseline image jpeg info
        base_info = self.get_format_prop(image_data)

        # Check iso hdr metadata
        base_image_size = base_info['image_size']
        base_data = image_data[: base_image_size]
        gain_map_data = []
        iso_hdr_result = base_info['iso_hdr'].tag
        mpf_data = base_info['mpf'].data
        mpf_data_offset = base_info['mpf'].offset
        mpf_ind_image_0_size = base_info['image_size']

        if (iso_hdr_result == ISO_21496_1_URN_STR) and (not mpf_data):
            mpf_result = {'mpf_valid_flag': False}
            LOG_I('mpf_valid_flag is false')
        else:
            mpf_data = list(mpf_data)
            mpf_result = self.mpf_extractor(mpf_data, mpf_data_offset)
            if mpf_result:
                if mpf_result['mpf_valid_flag'] is True:
                    gain_map_offset = mpf_result['ind_image_0_size']
                    gain_map_len = mpf_result['ind_image_1_size']
                    gain_map_data = image_data[gain_map_offset: gain_map_offset + gain_map_len]
                else:
                    mpf_result = {'mpf_valid_flag': False}
            else:
                mpf_result = {'mpf_valid_flag': False}

        # Save hdr image type
        if iso_hdr_result:
            hdr_image_type = ISO_21496_1_GAIN_MAP_HDR
        else:
            hdr_image_type = SDR

        # Initialize gain map hdr image decoded class
        gain_map_hdr_image_decoded = GainMapHdrImage()
        gain_map_hdr_image_decoded.hdr_type = hdr_image_type

        # Decode baseline image
        gain_map_hdr_image_decoded.baseline_image = self.base_image_decoder(base_data, base_info)

        # Decode gain map
        base_orientation = gain_map_hdr_image_decoded.baseline_image.prop.exif.orientation
        if (hdr_image_type != SDR) and gain_map_data:
            gain_map_hdr_image_decoded.gain_map = self.gain_map_decoder(gain_map_data, base_orientation)
        else:
            gain_map_hdr_image_decoded.gain_map = None

        return gain_map_hdr_image_decoded


    def gain_map_encoder(self, gain_map: GainMap) -> bytes | None:

        gm = gain_map.image_rgb
        gm_md_payload = gain_map.metadata_payload
        gm_md_param = gain_map.metadata_param
        gm_icc = gain_map.prop.icc_profile
        # TODO: support gain map icc profile encoding

        # Set JPEG encoder parameters
        jpeg_encode_params = [cv2.IMWRITE_JPEG_QUALITY, 90]

        # Get gain map property from metadata
        is_multichannel = gm_md_payload.is_multichannel

        # Encode gain map image
        if is_multichannel == 0:
            # Only reserve monochrome for encoding
            if gm.shape[-1] == 3:
                gm_data = gm[:, :, 0]
            elif gm.shape[-1] == 1:
                gm_data = gm
            elif len(gm.shape) == 2:
                gm_data = gm
            else:
                LOG_E('Gain map data dimension does not match monochrome!')
                return None
        else:
            if gm.shape[-1] == 3:
                gm_data = gm
            else:
                LOG_E('Gain map data dimension does not match multi-channel!')
                return None

        ret_gm, buffer_gm = cv2.imencode('.jpg', gm_data, jpeg_encode_params)

        if ret_gm:
            jpeg_gm_bytes = buffer_gm.tobytes()
        else:
            LOG_E('Gain map JPEG encoding failed!')
            return None

        # Encode gain map metadata - ISO 21496-1 payload binary
        gm_md = gm_md_payload
        jpeg_gm_md_bytes = JPEG_APP2_GAIN_MAP_URN + gm_md.pack()

        # Join APP0 (JFIF), APP2 (ISO 21496-1) and data in JPEG file

        pt = 0
        # Check JPEG SOI
        soi_marker, = struct.unpack('>H', jpeg_gm_bytes[pt: pt + 2])
        if soi_marker != JPEG_SOI_MARKER:
            return None
        else:
            LOG_D('SOI: 0x%04x' % soi_marker)
            pt = pt + 2

        # Check JPEG app0 JFIF
        app0_marker, = struct.unpack('>H', jpeg_gm_bytes[pt: pt + 2])

        if app0_marker != JPEG_APP0_MARKER:
            return None
        else:
            LOG_D('APP0: 0x%04x' % app0_marker)
            pt = pt + 2

        app0_length, = struct.unpack('>H', jpeg_gm_bytes[pt: pt + 2])
        app0_jfif_marker = jpeg_gm_bytes[pt + 2: pt + 6].decode('ascii')

        if app0_jfif_marker != JPEG_APP0_JFIF_TAG:
            return None
        else:
            LOG_D('APP0 (JFIF): %s' % app0_jfif_marker)
            pt_gm_md_offset = pt + app0_length

        # Add APP2 tag for ISO 21496-1 metadata
        app2_marker_bytes = struct.pack('>H', JPEG_APP2_MARKER)
        iso_length_bytes = struct.pack('>H', len(jpeg_gm_md_bytes) + 2)

        # Joint JPEG APPn and data
        gm_and_md_bytes = jpeg_gm_bytes[: pt_gm_md_offset] + \
                          app2_marker_bytes + iso_length_bytes + jpeg_gm_md_bytes + \
                          jpeg_gm_bytes[pt_gm_md_offset: ]

        return gm_and_md_bytes


    def baseline_encoder(self, gain_map_hdr_image: GainMapHdrImage,
                         gain_map_len: int) -> bytes | None:

        base = gain_map_hdr_image.baseline_image.image_rgb
        gm_md = gain_map_hdr_image.gain_map.metadata_payload

        # Set JPEG encoder parameters
        jpeg_encode_params = [cv2.IMWRITE_JPEG_QUALITY, 100]

        # Encode baseline image
        base_bgr = cv2.cvtColor(base, cv2.COLOR_BGR2RGB)
        ret_base, buffer_base = cv2.imencode('.jpg', base_bgr, jpeg_encode_params)
        if ret_base:
            jpeg_base_bytes = buffer_base.tobytes()
        else:
            LOG_E('Baseline image JPEG encoding failed!')
            return None

        # Encode ISO 21496-1 metadata, including URN and version info
        jpeg_gm_md_bytes = JPEG_APP2_GAIN_MAP_URN + \
                           struct.pack('>HH',
                                       gm_md.minimum_version,
                                       gm_md.writer_version)

        # Join APP0 (JFIF), APP2 (ISO 21496-1),APP2 (MPF), APP2 (ICC profile)
        # and data in JPEG file
        pt = 0

        # Check JPEG SOI
        soi_marker, = struct.unpack('>H', jpeg_base_bytes[pt: pt + 2])
        if soi_marker != JPEG_SOI_MARKER:
            return None
        else:
            LOG_D('SOI: 0x%04x' % soi_marker)
            pt = pt + 2

        # Check JPEG app0 JFIF
        app0_marker, = struct.unpack('>H', jpeg_base_bytes[pt: pt + 2])
        if app0_marker != JPEG_APP0_MARKER:
            return None
        else:
            LOG_D('APP0: 0x%04x' % app0_marker)
            pt = pt + 2
        app0_length, = struct.unpack('>H', jpeg_base_bytes[pt: pt + 2])
        app0_jfif_marker = jpeg_base_bytes[pt + 2: pt + 6].decode('ascii')
        if app0_jfif_marker != JPEG_APP0_JFIF_TAG:
            return None
        else:
            LOG_D('APP0 (JFIF): %s' % app0_jfif_marker)
            pt_base_info_offset = pt + app0_length

        # Add APP2 tag for ISO 21496-1 metadata
        app2_marker_bytes = struct.pack('>H', JPEG_APP2_MARKER)
        iso_length_bytes = struct.pack('>H', len(jpeg_gm_md_bytes) + 2)
        app2_iso_bytes = app2_marker_bytes + iso_length_bytes + jpeg_gm_md_bytes

        # Add APP2 tag for ICC profile
        if gain_map_hdr_image.baseline_image.prop.icc_profile_bytes:
            base_icc_bytes = JPEG_APP2_ICC_PROFILE_TAG + \
                             gain_map_hdr_image.baseline_image.prop.icc_profile_bytes
            app2_marker_bytes = struct.pack('>H', JPEG_APP2_MARKER)
            icc_length_bytes = struct.pack('>H', len(base_icc_bytes) + 2)
            app2_icc_bytes = app2_marker_bytes + icc_length_bytes + base_icc_bytes
        else:
            app2_icc_bytes = b''

        # Add APP2 tag for MPF
        # JPEG APPn sequence: APP0 (JFIF), APP2 (ISO), APP2 (MPF), APP2 (ICC)
        # There are only APP0 (JFIF), APP2 (ISO) before APP2 (MPF)
        app2_mpf_bytes = self.mpf_encoder(len(jpeg_base_bytes),
                                          pt_base_info_offset,
                                          len(app2_iso_bytes),
                                          len(app2_icc_bytes),
                                          gain_map_len)

        # Joint JPEG APPn and data
        # JPEG APPn sequence: APP0 (JFIF), APP2 (ISO), APP2 (MPF), APP2 (ICC)
        base_and_info_bytes = jpeg_base_bytes[: pt_base_info_offset] + \
                              app2_iso_bytes + app2_mpf_bytes + app2_icc_bytes + \
                              jpeg_base_bytes[pt_base_info_offset:]

        return base_and_info_bytes


    def encoder(self, gain_map_hdr_image: GainMapHdrImage, output_path: str) -> int:

        # Encode gain map and metadata
        gm_bytes = self.gain_map_encoder(gain_map_hdr_image.gain_map)

        if gm_bytes is None:
            return ENCODER_RET_FAILURE

        # Encode baseline image and metadata
        baseline_bytes = self.baseline_encoder(gain_map_hdr_image, len(gm_bytes))

        if gm_bytes is None:
            return ENCODER_RET_FAILURE

        # Joint baseline image and gain map
        gm_hdr_encoded_bytes = baseline_bytes + gm_bytes

        # Save encoded gain map HDR image
        try:
            with open(output_path, 'wb') as fp:
                fp.write(gm_hdr_encoded_bytes)

                return ENCODER_RET_SUCCESS
        except IOError as e:
            LOG_E(f'Save encoded gain map HDR image failed: {e}')

            return ENCODER_RET_FAILURE


if __name__ == "__main__":

    LOG_I('Gain map HDR image JPEG codec module...')
