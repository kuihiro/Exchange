################################################################
# Copyright (c) 2026 Honor Device Co., Ltd. All rights reserved.
#
# Hardware Engineering Dept.
# Display Platform Technologies Dept.
#
# Author: Ding Yue 00012140 <dingyue2@honor.com>
################################################################


##################################################
############ HDR Image Type Definition ###########
##################################################

ISO_21496_1_GAIN_MAP_HDR = 'ISO 21496-1'
ULTRA_HDR = 'Ultra HDR'
ISO_21496_1_GAIN_MAP_HDR_AND_ULTRA_HDR = 'ISO 21496-1 and Ultra HDR'
SDR = 'SDR'


##################################################
############# HDR Luminance Definition ###########
##################################################

SDR_MAX_LUMINANCE_BASED_ON_100_NITS = 100.0
HDR_REFERENCE_WHITE_LUMINANCE = 203.0
HDR_PQ_MAX_LUMINANCE = 10000.0


##################################################
################# CICP Definition ################
##################################################

# Refer to spec of H.273

# CICP - color primaries
CICP_COLOR_PRIMARIES_SRGB = 1
CICP_COLOR_PRIMARIES_BT601_625 = 5
CICP_COLOR_PRIMARIES_BT601_525 = 6
CICP_COLOR_PRIMARIES_BT2020 = 9
CICP_COLOR_PRIMARIES_BT2100 = 9
CICP_COLOR_PRIMARIES_P3 = 12

# CICP - transfer characteristics
CICP_TRANSFER_CHARACTERISTICS_BT709 = 1
CICP_TRANSFER_CHARACTERISTICS_GAMMA22 = 4
CICP_TRANSFER_CHARACTERISTICS_GAMMA28 = 5
CICP_TRANSFER_CHARACTERISTICS_BT601 = 6
CICP_TRANSFER_CHARACTERISTICS_SMPTE240 = 7
CICP_TRANSFER_CHARACTERISTICS_LINEAR = 8
CICP_TRANSFER_CHARACTERISTICS_LOG100_TO1 = 9
CICP_TRANSFER_CHARACTERISTICS_LOG100_SQRT10_TO1 = 10
CICP_TRANSFER_CHARACTERISTICS_IEC61966_2_4 = 11
CICP_TRANSFER_CHARACTERISTICS_BT1361_0 = 12
CICP_TRANSFER_CHARACTERISTICS_SRGB = 13
CICP_TRANSFER_CHARACTERISTICS_BT2020_10BIT = 14
CICP_TRANSFER_CHARACTERISTICS_BT2020_12BIT = 15
CICP_TRANSFER_CHARACTERISTICS_PQ = 16
CICP_TRANSFER_CHARACTERISTICS_SMPTE428_1 = 17
CICP_TRANSFER_CHARACTERISTICS_HLG = 18

# CICP - matrix coefficient
CICP_MATRIX_COEFFICIENT_IDENTITY = 0
CICP_MATRIX_COEFFICIENT_BT709 = 1
CICP_MATRIX_COEFFICIENT_BT601_625 = 5
CICP_MATRIX_COEFFICIENT_BT601_525 = 6
CICP_MATRIX_COEFFICIENT_BT2020 = 9
CICP_MATRIX_COEFFICIENT_BT2100 = 9

# CICP - full range flag
CICP_LIMITED_RANGE = 0
CICP_FULL_RANGE = 1

# CICP mapping - color primaries
cicp_tag_color_primaries_mapping = {
    0: "Reserved",
    1: "sRGB",
    2: "Unspecified",
    3: "Reserved",
    4: "4 (Refer to H.273)",
    5: "BT.601 (625)",
    6: "BT.601 (525)",
    7: "SMPTE 240",
    8: "Generic film",
    9: "BT.2020 or BT.2100",
    10: "SMPTE 428-1",
    11: "SMPTE 431-2",
    12: "P3",
    13: "Reserved",
    14: "Reserved",
    15: "Reserved",
    16: "Reserved",
    17: "Reserved",
    18: "Reserved",
    19: "Reserved",
    20: "Reserved",
    21: "Reserved",
    22: "22 (Refer to H.273)"
}

# CICP mapping - transfer characteristics
cicp_tag_transfer_characteristics_mapping = {
    0: "Reserved",
    1: "BT.709",
    2: "Unspecified",
    3: "Reserved",
    4: "Gamma 2.2",
    5: "Gamma 2.8",
    6: "BT.601 (525 or 625)",
    7: "SMPTE 240",
    8: "Linear transfer characteristics",
    9: "Log (100:1 range)",
    10: "Log (100 * Sqrt( 10 ) : 1 range)",
    11: "IEC 61966-2-4",
    12: "BT.1361-0",
    13: "sRGB",
    14: "BT.2020 (10-bit system)",
    15: "BT.2020 (12-bit system)",
    16: "PQ",
    17: "SMPTE 428-1",
    18: "HLG"
}

# CICP mapping - matrix coefficient
cicp_tag_matrix_coefficients_mapping = {
    0: "Identity",
    1: "BT.709",
    2: "Unspecified",
    3: "Reserved",
    4: "4 (Refer to H.273)",
    5: "BT.601 (625)",
    6: "BT.601 (525)",
    7: "SMPTE 240",
    8: "8 (Refer to H.273)",
    9: "BT.2100 (non-constant)",
    10: "BT.2100 (constant)",
    11: "SMPTE 2085",
    12: "12 (Refer to H.273)",
    13: "12 (Refer to H.273)",
    14: "ICTCP"
}

# CICP mapping - full range flag
cicp_tag_full_range_flag_mapping = {
    0: 'Limited Range',
    1: 'Full Range'
}


##################################################
############ Chroma Related Definition ###########
##################################################

# sRGB gamut color primaries - CIEXYZ
SRGB_GAMUT_RED_PRIMARIES_CIEXYZ = (0.43603514869801074,
                                   0.22248840582960838,
                                   0.013916015621759925)
SRGB_GAMUT_GREEN_PRIMARIES_CIEXYZ = (0.38511657170374747,
                                     0.7169037145285984,
                                     0.09706115883375332)
SRGB_GAMUT_BLUE_PRIMARIES_CIEXYZ = (0.143051140209991,
                                    0.06060790921083026,
                                    0.7139129779034192)

# P3 gamut color primaries - CIEXYZ
P3_GAMUT_RED_PRIMARIES_CIEXYZ = (0.5151214675242954,
                                 0.24119567888760685,
                                 -0.0010528564450673628)
P3_GAMUT_GREEN_PRIMARIES_CIEXYZ = (0.2919769139748496,
                                   0.6922454704317715,
                                   0.04188537759659994)
P3_GAMUT_BLUE_PRIMARIES_CIEXYZ = (0.157104494013538,
                                  0.06657409410308901,
                                  0.7840728923247298)

# BT.2020 gamut color primaries - CIEXYZ
BT2020_GAMUT_RED_PRIMARIES_CIEXYZ = (0.67348, 0.27904, -0.00194)
BT2020_GAMUT_GREEN_PRIMARIES_CIEXYZ = (0.16566, 0.67534, 0.02998)
BT2020_GAMUT_BLUE_PRIMARIES_CIEXYZ = (0.12505, 0.04561, 0.79684)

# White point - D50
WHITE_POINT_D50 = (0.9641876220703125,
                   1.0,
                   0.82489013671875)

# White point - D65
WHITE_POINT_D65 = (0.9504547119140625,
                   1.0,
                   1.08905029296875)

# Chromatic adaption from D50 to D65
CHROMATIC_ADAPTION_D50_TO_D65 = ((1.047882080078125, 0.022918701171875, -0.050201416015625),
                                 (0.0295867919921875, 0.990478515625, -0.017059326171875),
                                 (-0.0092315673828125, 0.01507568359375, 0.751678466796875))

# Color primaries xy

# D65, sRGB gamut color primaries
SRGB_D65_COLOR_PRIMARIES_RED_XY = [0.64, 0.33]
SRGB_D65_COLOR_PRIMARIES_GREEN_XY = [0.30, 0.60]
SRGB_D65_COLOR_PRIMARIES_BLUE_XY = [0.15, 0.06]

# D65, P3 gamut color primaries
P3_D65_COLOR_PRIMARIES_RED_XY = [0.68, 0.32]
P3_D65_COLOR_PRIMARIES_GREEN_XY = [0.265, 0.69]
P3_D65_COLOR_PRIMARIES_BLUE_XY = [0.15, 0.06]

# D65, BT.2020 gamut color primaries
P3_BT2020_COLOR_PRIMARIES_RED_XY = [0.708, 0.292]
P3_BT2020_COLOR_PRIMARIES_GREEN_XY = [0.170, 0.797]
P3_BT2020_COLOR_PRIMARIES_BLUE_XY = [0.131, 0.046]

# Color primaries mapping
COLOR_PRIMARIES_MAPPING = {
    'sRGB': {
        'red':   SRGB_D65_COLOR_PRIMARIES_RED_XY,
        'green': SRGB_D65_COLOR_PRIMARIES_GREEN_XY,
        'blue':  SRGB_D65_COLOR_PRIMARIES_BLUE_XY
    },
    'display-p3': {
        'red':   P3_D65_COLOR_PRIMARIES_RED_XY,
        'green': P3_D65_COLOR_PRIMARIES_GREEN_XY,
        'blue':  P3_D65_COLOR_PRIMARIES_BLUE_XY
    },
    'bt.2020': {
        'red':   P3_BT2020_COLOR_PRIMARIES_RED_XY,
        'green': P3_BT2020_COLOR_PRIMARIES_GREEN_XY,
        'blue':  P3_BT2020_COLOR_PRIMARIES_BLUE_XY
    }
}


##################################################
### Matrix Convert From Linear RGB to Luminance ##
##################################################
MATRIX_RGB_TO_LUMINANCE_SRGB = [0.21269, 0.71514, 0.07217]
MATRIX_RGB_TO_LUMINANCE_P3 = [0.2290, 0.6917, 0.0793]
MATRIX_RGB_TO_LUMINANCE_BT2020 = [0.2627, 0.6780, 0.0593]


##################################################
##################### Others #####################
##################################################

# Comments on struct.pack/unpack
# B: unsigned int(8)
# b: int(8)
# I: unsigned int(32)
# i: int(32)
# H: unsigned int(16)
# h: int(16)


##################################################
################ Class definition ################
##################################################

# CICP tag definition
class Cicp(object):

    def __init__(self):

        self.color_primaries = None
        self.transfer_function = None
        self.matrix_coefficient = None
        self.full_range_flag = None


# Exif information definition
class ExifInfo(object):

    def __init__(self):

        self.orientation = None
        self.orientation_rectified = False
        self.make = ''
        self.model = ''
        self.color_space = None


# Image properties definition
class ImageProp(object):

    def __init__(self):
            self.type = None
            self.planes = 3
            self.width = 0
            self.height = 0
            self.bit_depth = 8
            self.data_type = 'unknown'
            self.white_point = 'D65'
            self.hdr_ref_white = 203.0
            self.adrc_gain = 1.0
            self.scene_hdr_ratio = 1.0
            self.max_cll = 0
            self.max_fall = 0
            self.cicp = Cicp()
            self.icc_profile = None
            self.exif = ExifInfo()


# Baseline image definition
class BaselineImage(object):

    def __init__(self):

        self.prop = ImageProp()
        self.image_rgb = None
        self.image_path = ''


# Gain map definition
class GainMap(object):

    def __init__(self):

        self.prop = ImageProp()
        self.metadata_payload = None
        self.metadata_param = None
        self.image_rgb = None
        self.image_path = ''


# Gain map HDR image definition
class GainMapHdrImage(object):

    def __init__(self):

        self.hdr_type = ''
        self.baseline_image = BaselineImage()
        self.gain_map = GainMap()


# Single layer HDR image definition
class HdrImage(object):
    def __init__(self):
        self.hdr_type = 'single layer'
        self.prop = ImageProp()
        self.image_rgb = None
        self.image_path = None
