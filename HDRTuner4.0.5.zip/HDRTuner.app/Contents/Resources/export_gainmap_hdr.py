#!/usr/bin/env python3

import json
import os
import sys
from pathlib import Path

SCRIPT_DIR = Path(__file__).resolve().parent
if str(SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPT_DIR))

try:
    import cv2
    import gain_map_metadata as gmmd
    import jpeg
    from comm import GainMap, GainMapHdrImage, ISO_21496_1_GAIN_MAP_HDR
except ModuleNotFoundError as exc:
    missing = exc.name or "unknown"
    print(
        "Missing Python dependency for GainMapHDR export. "
        "Please install required packages, e.g. "
        "`pip install numpy opencv-python piexif pillow`.\n"
        f"Missing module: {missing}",
        file=sys.stderr,
    )
    raise


def _scale_to_rational(value: float) -> tuple[int, int]:
    return int(round(float(value) * 1_000_000.0)), 1_000_000


def _load_gain_map_metadata(json_path: str):
    with open(json_path, "r", encoding="utf-8") as fp:
        src = json.load(fp)

    is_multi = int(src["isMultiChannel"]) != 0
    use_base = int(src["useBaseColourSpace"]) != 0

    if is_multi:
        md = gmmd.GainMapMetadataMc()
        md.is_multichannel = 1
        md.use_base_colour_space = 1 if use_base else 0
        md.base_hdr_headroom_numerator, md.base_hdr_headroom_denominator = _scale_to_rational(src["baseHdrHeadroom"])
        md.alternate_hdr_headroom_numerator, md.alternate_hdr_headroom_denominator = _scale_to_rational(src["alternateHdrHeadroom"])
        md.gain_map_min_rc_numerator, md.gain_map_min_rc_denominator = _scale_to_rational(src["gainMapMinRC"])
        md.gain_map_max_rc_numerator, md.gain_map_max_rc_denominator = _scale_to_rational(src["gainMapMaxRC"])
        md.gamma_rc_numerator, md.gamma_rc_denominator = _scale_to_rational(src["gammaRC"])
        md.base_offset_rc_numerator, md.base_offset_rc_denominator = _scale_to_rational(src["baseOffsetRC"])
        md.alternate_offset_rc_numerator, md.alternate_offset_rc_denominator = _scale_to_rational(src["alternateOffsetRC"])
        md.gain_map_min_gc_numerator, md.gain_map_min_gc_denominator = _scale_to_rational(src["gainMapMinGC"])
        md.gain_map_max_gc_numerator, md.gain_map_max_gc_denominator = _scale_to_rational(src["gainMapMaxGC"])
        md.gamma_gc_numerator, md.gamma_gc_denominator = _scale_to_rational(src["gammaGC"])
        md.base_offset_gc_numerator, md.base_offset_gc_denominator = _scale_to_rational(src["baseOffsetGC"])
        md.alternate_offset_gc_numerator, md.alternate_offset_gc_denominator = _scale_to_rational(src["alternateOffsetGC"])
        md.gain_map_min_bc_numerator, md.gain_map_min_bc_denominator = _scale_to_rational(src["gainMapMinBC"])
        md.gain_map_max_bc_numerator, md.gain_map_max_bc_denominator = _scale_to_rational(src["gainMapMaxBC"])
        md.gamma_bc_numerator, md.gamma_bc_denominator = _scale_to_rational(src["gammaBC"])
        md.base_offset_bc_numerator, md.base_offset_bc_denominator = _scale_to_rational(src["baseOffsetBC"])
        md.alternate_offset_bc_numerator, md.alternate_offset_bc_denominator = _scale_to_rational(src["alternateOffsetBC"])
        return md

    md = gmmd.GainMapMetadataSc()
    md.is_multichannel = 0
    md.use_base_colour_space = 1 if use_base else 0
    md.base_hdr_headroom_numerator, md.base_hdr_headroom_denominator = _scale_to_rational(src["baseHdrHeadroom"])
    md.alternate_hdr_headroom_numerator, md.alternate_hdr_headroom_denominator = _scale_to_rational(src["alternateHdrHeadroom"])
    md.gain_map_min_numerator, md.gain_map_min_denominator = _scale_to_rational(src["gainMapMinRC"])
    md.gain_map_max_numerator, md.gain_map_max_denominator = _scale_to_rational(src["gainMapMaxRC"])
    md.gamma_numerator, md.gamma_denominator = _scale_to_rational(src["gammaRC"])
    md.base_offset_numerator, md.base_offset_denominator = _scale_to_rational(src["baseOffsetRC"])
    md.alternate_offset_numerator, md.alternate_offset_denominator = _scale_to_rational(src["alternateOffsetRC"])
    return md


def _load_baseline_image(codec: jpeg.GainMapHdrCodec, baseline_path: str):
    with open(baseline_path, "rb") as fp:
        base_bytes = fp.read()
    base_info = codec.get_format_prop(base_bytes)
    return codec.base_image_decoder(base_bytes, base_info)


def _load_gain_map_rgb(gain_map_path: str):
    image = cv2.imread(gain_map_path, cv2.IMREAD_UNCHANGED)
    if image is None:
        raise RuntimeError(f"Failed to load gain map image: {gain_map_path}")

    if len(image.shape) == 2:
        return image

    channels = image.shape[2]
    if channels == 4:
        return cv2.cvtColor(image, cv2.COLOR_BGRA2RGB)
    if channels == 3:
        return cv2.cvtColor(image, cv2.COLOR_BGR2RGB)

    raise RuntimeError(f"Unsupported gain map image channel count: {channels}")


def main() -> int:
    if len(sys.argv) != 5:
        print(
            "Usage: export_gainmap_hdr.py <baseline.jpg> <gain_map.png> <metadata.json> <output.jpg>",
            file=sys.stderr,
        )
        return 2

    baseline_path, gain_map_path, metadata_path, output_path = sys.argv[1:5]

    codec = jpeg.GainMapHdrCodec()
    baseline_image = _load_baseline_image(codec, baseline_path)
    metadata_payload = _load_gain_map_metadata(metadata_path)
    gain_map_rgb = _load_gain_map_rgb(gain_map_path)

    gain_map = GainMap()
    gain_map.image_rgb = gain_map_rgb
    gain_map.metadata_payload = metadata_payload
    gain_map.metadata_param = metadata_payload.get_params()

    gain_map_hdr_image = GainMapHdrImage()
    gain_map_hdr_image.hdr_type = ISO_21496_1_GAIN_MAP_HDR
    gain_map_hdr_image.baseline_image = baseline_image
    gain_map_hdr_image.gain_map = gain_map

    result = codec.encoder(gain_map_hdr_image, output_path)
    if result != jpeg.ENCODER_RET_SUCCESS:
        return int(result)

    print(output_path)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
