#!/usr/bin/env python3
"""
clip_exr_rgb.py

Reads R, G, B channels (float32 / float16) from an OpenEXR file,
clips each pixel value to MAX_VALUE, and writes out a new OpenEXR file.

Additionally, if a metadata JSON file is provided as the third argument,
its contents are formatted as text and overlaid onto the image (R/G/B)
in the bottom-right corner before writing the output EXR.

Usage:
  python clip_exr_rgb.py input.exr output.exr [metadata.json]
"""

import sys
import json
from typing import Dict, List, Any, Tuple, Optional

import numpy as np
import OpenEXR
import Imath
from PIL import Image, ImageDraw, ImageFont
import matplotlib.pyplot as plt
from matplotlib.ticker import MultipleLocator
import seaborn as sns


# Sensor capacity definition
CAPTURED_MAX_EV = 8.0 # Based on log2

# Clip parameters default value
SCENE_LIGHT_CLIP_LOW_PERCENT = 0.0
SCENE_LIGHT_CLIP_HIGH_PERCENT = 100.0

# Tone curve type definition
TONE_CURVE_DATA_TYPE_LUMINANCE = 0
TONE_CURVE_DATA_TYPE_MAX_RGB = 1
TONE_CURVE_DATA_TYPE_COMB_DENSITY = 2
tone_curve_data_type_desc_mapping = {
    TONE_CURVE_DATA_TYPE_LUMINANCE: "Luminance",
    TONE_CURVE_DATA_TYPE_MAX_RGB: "MaxRGB",
    TONE_CURVE_DATA_TYPE_COMB_DENSITY: "CombDensity",
}

# Luminance definition
EXR_REF_WHITE_LUMINANCE = 100.0
HDR_REF_WHITE_LUMINANCE = 203.0
CONTENT_TARGET_LUMINANCE_MAX = 1000.0
DISPLAY_LIGHT_LUMINANCE_CLIP_MIN = 0.0
DISPLAY_LIGHT_LUMINANCE_CLIP_MAX = 6400.0
PQ_MAX_LUMINANCE_NITS = 10000.0

# CICP color primaries definition
CICP_COLOR_PRIMARIES_SRGB = 1
CICP_COLOR_PRIMARIES_BT2020 = 9
CICP_COLOR_PRIMARIES_P3 = 12

# CICP transfer characteristics
CICP_TRANSFER_CHARACTERISTICS_PQ = 16
CICP_TRANSFER_CHARACTERISTICS_HLG = 18

# CICP color primaries description mapping
cicp_color_primaries_desc_mapping = {
    CICP_COLOR_PRIMARIES_SRGB:   "sRGB",
    CICP_COLOR_PRIMARIES_BT2020: "BT2020",
    CICP_COLOR_PRIMARIES_P3:     "P3"
}

# RGB to luminance matrix
MATRIX_RGB_TO_LUMINANCE_SRGB = [0.21269, 0.71514, 0.07217]
MATRIX_RGB_TO_LUMINANCE_P3 = [0.2290, 0.6917, 0.0793]
MATRIX_RGB_TO_LUMINANCE_BT2020 = [0.2627, 0.6780, 0.0593]
MATRIX_RGB_TO_LUMINANCE_BT2100 = [0.2627, 0.6780, 0.0593]


def reference_ootf_pq(E: np.ndarray) -> np.ndarray:
    # Follow ITU-R BT.2100-2, Table - 4
    # E is in the range [0.0, 1.0]
    # E' is a non-linear representation of E
    # E' = 1.099 * (59.5208 * E) ^ 0.45 - 0.099, for 0.0003024 < E <= 1
    # E' = 267.84 * E                          , for 0 <= E <= 0.0003024
    # Fd = 100 * E' ^ 2.4

    E = np.clip(E, 0.0, 1.0)

    Fd = np.zeros_like(E, dtype='float32')
    mask_1 = (E > 0.0003024) & (E <= 1.0)
    mask_2 = (E >= 0.0) & (E <= 0.0003024)

    Fd[mask_1] = 100 * ((1.099 * ((59.5208 * E[mask_1]) ** 0.45) - 0.099) ** 2.4)
    Fd[mask_2] = 100 * ((267.84 * E[mask_2]) ** 2.4)

    return Fd


def reference_ootf_hlg(E: np.ndarray) -> np.ndarray:

    # TODO: support hlg reference ootf
    return np.clip(E, 0.0, 1.0)


def tone_curve_function(x:   np.ndarray,
                        Ns:  float,
                        Nt:  float,
                        Ntw: float) -> np.ndarray:

    # Nsw - Normalized scene hdr reference white, fixed to 1.0
    # Ns  - Normalized scene dynamic range
    # Nt  - Normalized target content dynamic range
    # Ntw - Normalized target hdr reference white
    # y(x) = x * (Ntw / Nsw), 0.0 < x <= Nsw
    # y(x) = B(t),            Nsw < x <= Ns
    # y(x) = Nt,              Ns < x

    Nsw = 1.0

    y = np.zeros_like(x, dtype='float32')

    slope_1 = (0.0 < x) & (x <= Nsw)
    slope_2 = (Nsw < x) & (x <= Ns)
    slope_3 = (x > Ns)

    # y(x) slope 1 part: linear scale
    y[slope_1] = x[slope_1] * (Ntw / Nsw)

    # y(x) slope 2 part: Beziers quadratic function
    p_1_x = Nt / Ntw
    a_0 = 1.0 + Ns - 2.0 * p_1_x
    min_a = 0.001 / 3.0
    if abs(a_0) < min_a:
        p_2_x = Ns + min_a - a_0
    else:
        p_2_x = Ns
    a = 1.0 + p_2_x - 2 * p_1_x
    b = p_1_x ** 2.0 - p_2_x
    c = 1.0 - p_1_x
    d = Ntw - Nt
    t = (((a * x[slope_2] + b) ** 0.5) + c) / a
    y[slope_2] = Ntw + d * (t - 2.0) * t

    # y(x) slope 3 part: upper limit
    y[slope_3] = Nt

    return y


def plot_tone_curve(Ns:  float,
                    Nt: float,
                    Ntw:  float,
                    flag: Optional[bool]=False) -> None:

    if not flag:
        return

    x = np.linspace(0, Ns, 1000)
    y = tone_curve_function(x, Ns, Nt, Ntw)

    # Plot curve
    plt.plot(x, y, color="blue", linestyle='-', linewidth=1.5, alpha=0.8)

    # Text parameters
    params_text = f"Ns = {Ns:.2f}\nNtw = {Ntw:.2f}\nNt = {Nt:.2f}"
    plt.plot([], [], label=params_text, alpha=0.0)

    # Plot x-axis ticks and labels
    x_ticks = list(range(0, int(Ns) + 2))
    if Ns not in x_ticks:
        x_ticks.append(Ns)
    x_ticks = sorted(x_ticks)
    x_labels = [""] * len(x_ticks)
    x_labels[0] = f"{x_ticks[0]:.1f}"
    x_labels[x_ticks.index(1)] = f"{x_ticks[1]:.1f}"
    x_labels[x_ticks.index(Ns)] = f"Ns"

    print("x_ticks = ", x_ticks)
    print("x_labels = ", x_labels)

    plt.gca().set_xticks(x_ticks)
    plt.gca().set_xticklabels(x_labels)

    # Plot y-axis ticks and labels
    y_ticks = list(range(0, int(Nt) + 2))
    if Nt not in y_ticks:
        y_ticks.append(Nt)
    if Ntw not in y_ticks:
        y_ticks.append(Ntw)
    y_ticks = sorted(y_ticks)
    y_labels = [""] * len(y_ticks)
    y_labels[0] = f"{y_ticks[0]:.1f}"
    y_labels[y_ticks.index(Ntw)] = f"Ntw"
    y_labels[y_ticks.index(Nt)] = f"Nt"
    plt.gca().set_yticks(y_ticks)
    plt.gca().set_yticklabels(y_labels)

    print("y_ticks = ", y_ticks)
    print("y_labels = ", y_labels)

    # Plot marked line
    plt.scatter(1.0, Ntw, color="black", s=10, alpha=0.8, zorder=5)
    plt.plot([0.0, 1.0], [Ntw, Ntw], color="gray", linestyle='--')
    plt.plot([1.0, 1.0], [0.0, Ntw], color="gray", linestyle='--')

    # Set plot common properties
    plt.gca().set_aspect("equal", adjustable="box")
    plt.xlabel("Normalized linear RGB in", labelpad=10)
    plt.ylabel("Normalized linear RGB out", labelpad=10)
    plt.legend(loc="best", frameon=False)
    plt.title("Tone Curve - Scene DR to Target Content DR")

    plt.show()

def plot_rgb_histogram(rgb: np.ndarray,
                       down_sampling_ratio:Optional[int]=16,
                       flag: Optional[bool]=False) -> None:
    if not flag:
        return

    # Get down sampling data
    rgb_ds = rgb[::down_sampling_ratio, ::down_sampling_ratio, :]

    # Convert np to list for plotting
    r = rgb_ds[:, :, 0].flatten().tolist()
    g = rgb_ds[:, :, 1].flatten().tolist()
    b = rgb_ds[:, :, 2].flatten().tolist()

    # Plot density histogram
    sns.kdeplot(r, color="red", fill=True,
                label=f"Red [{min(r):.2f}, {max(r):.2f}]")
    sns.kdeplot(g, color="green", fill=True,
                label=f"Green [{min(g):.2f}, {max(g):.2f}]")
    sns.kdeplot(b, color="blue", fill=True,
                label=f"Blue [{min(b):.2f}, {max(b):.2f}]")

    # Set plotting properties
    plt.xlim(0.0)
    plt.ylim(0.0)
    plt.legend(loc="best", frameon=False)
    plt.title("EXR Data R/G/B Histogram")
    plt.show()


def clip_low_high_percent_rgb(rgb: np.ndarray,
                              low_p: float,
                              high_p: float) -> np.ndarray:

    low_val = np.percentile(rgb, low_p)
    high_val = np.percentile(rgb, high_p)

    if low_val < 0.0:
        low_val = 0.0
    if high_val <= 1.0:
        high_val = 1.0

    if low_val >= high_val:
        return rgb
    else:
        return np.clip(rgb, low_val, high_val)


def clip_rgb_protect_chroma(rgb: np.ndarray,
                            maxrgb_min: float,
                            maxrgb_max: float,
                            eps: Optional[float]=1e-6) -> np.ndarray:
    # Use maxrgb as scalar
    rgb_maxrgb = np.max(np.abs(rgb), axis=2, keepdims=True)
    abs_min = abs(maxrgb_min)
    abs_max = maxrgb_max
    rgb_maxrgb_clipped = np.clip(rgb_maxrgb, abs_min, abs_max)

    # Compute scale factor
    scale_factor = np.ones_like(rgb_maxrgb, dtype=np.float32) * abs_max
    mask = rgb_maxrgb > eps
    scale_factor[mask] = rgb_maxrgb_clipped[mask] / rgb_maxrgb[mask]

    # Apply scale factor
    rgb_clipped = rgb * scale_factor

    # Confirm clipped rgb in range of [maxrgb_min, maxrgb_max]
    rgb_out = np.clip(rgb_clipped, maxrgb_min, maxrgb_max)

    return rgb_out


def alt_image_ref_ootf(rgb_in: np.ndarray,
                       params_metadata: Dict[str, Any],
                       params_static_config: Dict[str, Any],
                       params_algo_runtime_args: Dict[str, Any],
                       emulation_status: bool,
                       ) -> Tuple[np.ndarray, Dict[str, Any]]:

    # Input parameters
    # rgb_in                   - exr rgb data, linear float
    # params_metadata          - parameters from exr metadata
    # params_static_config     - parameters from HDRTuner configuration
    # params_algo_runtime_args - parameters comes algorithm runtime output
    # emulation_status         - If emulation_status is True, the params_algo_runtime_args
    #                            will overlay the parameters generated by algorithm.
    #                            If emulation_status is False, use the parameters generated
    #                            by algorithm.
    # Return value
    # norm_rgb_out             - Normalized linear rgb by ref ootf + tone curve
    # output_algo_runtime_args - Algorithm runtime arguments

    # Show input parameters

    print("Parameters metadata:")
    print(params_metadata)
    print("Parameters static config:")
    print(params_static_config)
    print("Parameters algo runtime args:")
    print(params_algo_runtime_args)

    # Step 1: compute scene light rgb
    #         scene_light_rgb = rgb_in * adrc_gain

    adrc_gain = params_metadata['Captured ADRC Gain']
    scene_light_rgb = rgb_in * adrc_gain
    print("Scene light red-channel range [%.2f, %.2f]" %
          (scene_light_rgb[:, :, 0].min(), scene_light_rgb[:, :, 0].max()))
    print("Scene light green-channel range [%.2f, %.2f]" %
          (scene_light_rgb[:, :, 1].min(), scene_light_rgb[:, :, 0].max()))
    print("Scene light blue-channel range [%.2f, %.2f]" %
          (scene_light_rgb[:, :, 2].min(), scene_light_rgb[:, :, 2].max()))

    # Step 2: clip scene light rgb

    low_p = params_static_config["Scene Light Clip Low Percent (%)"]
    high_p = params_static_config["Scene Light Clip High Percent (%)"]
    clipped_scene_light_rgb = clip_low_high_percent_rgb(scene_light_rgb, low_p, high_p)
    print("Clipped scene light red-channel range [%.2f, %.2f]" %
          (clipped_scene_light_rgb[:, :, 0].min(), clipped_scene_light_rgb[:, :, 0].max()))
    print("Clipped scene light green-channel range [%.2f, %.2f]" %
          (clipped_scene_light_rgb[:, :, 1].min(), clipped_scene_light_rgb[:, :, 0].max()))
    print("Clipped scene light blue-channel range [%.2f, %.2f]" %
          (clipped_scene_light_rgb[:, :, 2].min(), clipped_scene_light_rgb[:, :, 2].max()))

    # Plot rgb histogram of clipped_scene_light_rgb
    plot_rgb_histogram(clipped_scene_light_rgb,
                       down_sampling_ratio=16,
                       flag=False)

    # Step 3: compute display light rgb by reference ootf, only support pq

    if emulation_status:
        scene_light_hdr_ratio = params_algo_runtime_args["Scene Light HDR Ratio"]
    else:
        scene_light_hdr_ratio = clipped_scene_light_rgb.max()

    print("Scene light HDR ratio = %.2f" % scene_light_hdr_ratio)

    # Process reference ootf
    ref_ootf_transfer_type = params_static_config["Ref OOTF Transfer Type (PQ: 16, HLG: 18)"]
    if ref_ootf_transfer_type == CICP_TRANSFER_CHARACTERISTICS_PQ:
        # Normalize scene light rgb
        norm_scene_light_rgb = (clipped_scene_light_rgb / clipped_scene_light_rgb.max()) * \
                               (scene_light_hdr_ratio *
                                params_static_config["EXR Ref White Luminance (nits)"] /
                                PQ_MAX_LUMINANCE_NITS)

        print("Norm scene light red-channel range [%.2f, %.2f]" %
              (norm_scene_light_rgb[:, :, 0].min(), norm_scene_light_rgb[:, :, 0].max()))
        print("Norm scene light green-channel range [%.2f, %.2f]" %
              (norm_scene_light_rgb[:, :, 1].min(), norm_scene_light_rgb[:, :, 0].max()))
        print("Norm scene light blue-channel range [%.2f, %.2f]" %
              (norm_scene_light_rgb[:, :, 2].min(), norm_scene_light_rgb[:, :, 2].max()))

        display_light_rgb = reference_ootf_pq(norm_scene_light_rgb)
    elif ref_ootf_transfer_type == CICP_TRANSFER_CHARACTERISTICS_HLG:
        norm_scene_light_rgb = clipped_scene_light_rgb / clipped_scene_light_rgb.max()
        display_light_rgb = reference_ootf_hlg(norm_scene_light_rgb)
    else:
        norm_scene_light_rgb = clipped_scene_light_rgb / clipped_scene_light_rgb.max()
        display_light_rgb = norm_scene_light_rgb
        # Need to warning and notification

    print("Display light red-channel range [%.2f, %.2f]" %
          (display_light_rgb[:, :, 0].min(), display_light_rgb[:, :, 0].max()))
    print("Display light green-channel range [%.2f, %.2f]" %
          (display_light_rgb[:, :, 1].min(), display_light_rgb[:, :, 0].max()))
    print("Display light blue-channel range [%.2f, %.2f]" %
          (display_light_rgb[:, :, 2].min(), display_light_rgb[:, :, 2].max()))

    # Clip display light
    display_light_clip_min = params_static_config["Display Light Luminance Clip Min (nits)"]
    display_light_clip_max = params_static_config["Display Light Luminance Clip Max (nits)"]
    if display_light_rgb.max() > display_light_clip_max:
        clipped_display_light_rgb = clip_rgb_protect_chroma(display_light_rgb,
                                                            display_light_clip_min,
                                                            display_light_clip_max)
        print("Clip display light rgb to [%.2f, %.2f]" %
              (display_light_clip_min, display_light_clip_max))
    else:
        clipped_display_light_rgb = display_light_rgb

    print("Clipped display light red-channel range [%.2f, %.2f]" %
          (clipped_display_light_rgb[:, :, 0].min(), clipped_display_light_rgb[:, :, 0].max()))
    print("Clipped display light green-channel range [%.2f, %.2f]" %
          (clipped_display_light_rgb[:, :, 1].min(), clipped_display_light_rgb[:, :, 0].max()))
    print("Clipped display light blue-channel range [%.2f, %.2f]" %
          (clipped_display_light_rgb[:, :, 2].min(), clipped_display_light_rgb[:, :, 2].max()))

    # Step 4: normalize display light rgb by hdr reference white luminance
    #         norm_rgb_in = clipped_display_light_rgb / exr_ref_white_luminance

    exr_ref_white_luminance = params_static_config["EXR Ref White Luminance (nits)"]
    norm_rgb_in = clipped_display_light_rgb / exr_ref_white_luminance

    print("Norm RGB in red-channel range [%.2f, %.2f]" %
          (norm_rgb_in[:, :, 0].min(), norm_rgb_in[:, :, 0].max()))
    print("Norm RGB in  green-channel range [%.2f, %.2f]" %
          (norm_rgb_in[:, :, 1].min(), norm_rgb_in[:, :, 0].max()))
    print("Norm RGB blue-channel range [%.2f, %.2f]" %
          (norm_rgb_in[:, :, 2].min(), norm_rgb_in[:, :, 2].max()))

    # Step 5: compute adaptive tone curve input data

    tc_data_type = params_static_config["TC Data Type (L: 0, MaxRGB: 1, Comb: 2)"]
    if tc_data_type == TONE_CURVE_DATA_TYPE_COMB_DENSITY:
        captured_gamut = params_metadata['Captured Gamut']
        if captured_gamut == CICP_COLOR_PRIMARIES_SRGB:
            norm_rgb_in_luminance = norm_rgb_in @ np.array(MATRIX_RGB_TO_LUMINANCE_SRGB)
        elif captured_gamut == CICP_COLOR_PRIMARIES_P3:
            norm_rgb_in_luminance = norm_rgb_in @ np.array(MATRIX_RGB_TO_LUMINANCE_P3)
        elif captured_gamut == CICP_COLOR_PRIMARIES_BT2020:
            norm_rgb_in_luminance = norm_rgb_in @ np.array(MATRIX_RGB_TO_LUMINANCE_BT2020)
        else:
            # Use sRGB as default
            norm_rgb_in_luminance = norm_rgb_in @ np.array(MATRIX_RGB_TO_LUMINANCE_SRGB)
        norm_rgb_in_maxrgb = np.max(norm_rgb_in, axis=-1)
        norm_rgb_in_comb_intensity = (norm_rgb_in_maxrgb + norm_rgb_in_luminance) / 2.0
        tc_input_data = norm_rgb_in_comb_intensity
    elif tc_data_type == TONE_CURVE_DATA_TYPE_LUMINANCE:
        captured_gamut = params_metadata['Captured Gamut']
        if captured_gamut == CICP_COLOR_PRIMARIES_SRGB:
            norm_rgb_in_luminance = norm_rgb_in @ np.array(MATRIX_RGB_TO_LUMINANCE_SRGB)
        elif captured_gamut == CICP_COLOR_PRIMARIES_P3:
            norm_rgb_in_luminance = norm_rgb_in @ np.array(MATRIX_RGB_TO_LUMINANCE_P3)
        elif captured_gamut == CICP_COLOR_PRIMARIES_BT2020:
            norm_rgb_in_luminance = norm_rgb_in @ np.array(MATRIX_RGB_TO_LUMINANCE_BT2020)
        else:
            # Use sRGB as default
            norm_rgb_in_luminance = norm_rgb_in @ np.array(MATRIX_RGB_TO_LUMINANCE_SRGB)
        tc_input_data = norm_rgb_in_luminance
    elif tc_data_type == TONE_CURVE_DATA_TYPE_MAX_RGB:
        norm_rgb_in_maxrgb = np.max(norm_rgb_in, axis=-1)
        tc_input_data = norm_rgb_in_maxrgb
    else:
        # Use MaxRGB as default tone curve input data type
        norm_rgb_in_maxrgb = np.max(norm_rgb_in, axis=-1)
        tc_input_data = norm_rgb_in_maxrgb

    print("Tone curve data type: %s" % tone_curve_data_type_desc_mapping[tc_data_type])
    print("Tone curve data range [%.2f, %.2f]" % (tc_input_data.min(), tc_input_data.max()))

    # Step 6: compute adaptive tone curve parameter

    hdr_ref_white_luminance = params_metadata["HDR Ref White Luminance (nits)"]

    if emulation_status:
        Ns = params_algo_runtime_args["Ns (Norm Scene Dynamic Range)"]
        Nt = params_algo_runtime_args["Nt (Norm Target Dynamic Range)"]
        Ntw = params_algo_runtime_args["Ntw (Norm Target Ref White)"]
    else:
        Ntw = hdr_ref_white_luminance / exr_ref_white_luminance
        Ns = max(tc_input_data.max(), Ntw)
        Nt = min(Ns / Ntw, CONTENT_TARGET_LUMINANCE_MAX / exr_ref_white_luminance)
        Nt = max(Nt, Ntw)

    print("Tone curve parameters: Ns = %.2f, Nt = %.2f, Ntw = %.2f" % (Ns, Nt, Ntw))

    # Plot tone curve
    plot_tone_curve(Ns, Nt, Ntw, flag=False)

    # Step 7: compute tone curve output

    x = tc_input_data
    y = tone_curve_function(x, Ns, Nt, Ntw)

    print("Tone curve output data range [%.2f, %.2f]" % (y.min(), y.max()))

    # Step 8: compute gain for each pixel, gain = y / x

    tc_gain = np.zeros_like(x, dtype='float32')
    tc_gain[x > 0] = y[y > 0] / x[x > 0]

    print("Tone curve gain range [%.2f, %.2f]" % (tc_gain.min(), tc_gain.max()))

    # Step 9: apply gain on input normalized rgb to get target rgb

    target_norm_rgb = norm_rgb_in * tc_gain[:, :, np.newaxis]

    print("target_norm_rgb red-channel range [%.2f, %.2f]" %
          (target_norm_rgb[:, :, 0].min(), target_norm_rgb[:, :, 0].max()))
    print("target_norm_rgb green-channel range [%.2f, %.2f]" %
          (target_norm_rgb[:, :, 1].min(), target_norm_rgb[:, :, 1].max()))
    print("target_norm_rgb blue-channel range [%.2f, %.2f]" %
          (target_norm_rgb[:, :, 2].min(), target_norm_rgb[:, :, 2].max()))

    # Step 10: clamp the target rgb

    clamped_r_out = np.clip(target_norm_rgb[:, :, 0], 0,
                            min(Nt, target_norm_rgb[:, :, 0].max()))
    clamped_g_out = np.clip(target_norm_rgb[:, :, 1], 0,
                            min(Nt, target_norm_rgb[:, :, 1].max()))
    clamped_b_out = np.clip(target_norm_rgb[:, :, 2], 0,
                            min(Nt, target_norm_rgb[:, :, 2].max()))
    clamped_rgb_out = np.dstack((clamped_r_out, clamped_g_out, clamped_b_out))

    print("clamped_rgb_out red-channel range [%.2f, %.2f]" %
          (clamped_rgb_out[:, :, 0].min(), clamped_rgb_out[:, :, 0].max()))
    print("clamped_rgb_out green-channel range [%.2f, %.2f]" %
          (clamped_rgb_out[:, :, 1].min(), clamped_rgb_out[:, :, 1].max()))
    print("clamped_rgb_out blue-channel range [%.2f, %.2f]" %
          (clamped_rgb_out[:, :, 2].min(), clamped_rgb_out[:, :, 2].max()))

    # Output normalized rgb by clamped_rgb_out

    norm_rgb_out = clamped_rgb_out

    # Set algorithm runtime parameters as return value
    output_algo_runtime_args = {
        "Scene Light HDR Ratio": scene_light_hdr_ratio,
        "Ntw (Norm Target Ref White)": Ntw,
        "Nt (Norm Target Dynamic Range)": Nt,
        "Ns (Norm Scene Dynamic Range)": Ns
    }

    return norm_rgb_out, output_algo_runtime_args


def format_metadata_for_overlay(meta: Dict[str, Any]) -> str:
    """
    Format metadata dict (name -> value) as a multi-line string suitable
    for overlay.

    - If value is int/float: format with up to 4 decimal places.
    - Otherwise: str(value).
    - Keys are processed in the insertion order, which corresponds to
      the order in the JSON file (for Python 3.7+).
    """
    lines: List[str] = []

    for key, value in meta.items():
        if isinstance(value, (int, float)):
            # Format with up to 4 decimal places, strip trailing zeros
            formatted = f"{value:.4f}".rstrip("0").rstrip(".")
        else:
            formatted = str(value)
        lines.append(f"{key}: {formatted}")

    return "\n".join(lines)


def _choose_font(draw: ImageDraw.ImageDraw, text: str,
                 img_width: int, img_height: int) -> ImageFont.FreeTypeFont:
    """
    Choose a TrueType font and size such that the text width is roughly
    half of the image width (not exceeding it too much). Falls back to
    default PIL font if no TTF is available.
    """
    target_fraction = 0.5
    target_width = img_width * target_fraction

    def measure_text_size(
        font_obj: ImageFont.FreeTypeFont
    ) -> Tuple[int, int]:
        # Try multiline_textbbox (newer Pillow) first, then multiline_textsize.
        if hasattr(draw, "multiline_textbbox"):
            bbox = draw.multiline_textbbox((0, 0), text, font=font_obj)
            width = bbox[2] - bbox[0]
            height = bbox[3] - bbox[1]
        else:
            width, height = draw.multiline_textsize(text, font=font_obj)
        return width, height

    try:
        font_path_candidates = [
            "DejaVuSans.ttf",
            "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
            "/Library/Fonts/Arial.ttf",
            "Arial.ttf",
        ]

        base_font_path = None
        for path in font_path_candidates:
            try:
                _ = ImageFont.truetype(path, size=10)
                base_font_path = path
                break
            except Exception:
                continue

        if base_font_path is None:
            raise RuntimeError("No suitable TrueType font found")

        font_size = 10
        font = ImageFont.truetype(base_font_path, size=font_size)
        text_width, _ = measure_text_size(font)

        # Increase font size until we approach target_width
        while text_width < target_width and font_size < 300:
            font_size += 2
            font = ImageFont.truetype(base_font_path, size=font_size)
            text_width, _ = measure_text_size(font)

        # If we overshot, step back once
        if text_width > target_width and font_size > 10:
            font_size -= 2
            font = ImageFont.truetype(base_font_path, size=font_size)

        return font

    except Exception:
        # Fallback to default font
        return ImageFont.load_default()


def overlay_text_on_rgb_channels(
    r: np.ndarray,
    g: np.ndarray,
    b: np.ndarray,
    text: str,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """
    Overlay the given text (multi-line) onto the provided R/G/B float
    arrays by drawing a mask in the bottom-right corner and blending
    the text color (MAX_VALUE) into those pixels.

    r, g, b are assumed to be float32 arrays of shape (H, W).
    """
    # Ensure float32
    r = r.astype(np.float32, copy=False)
    g = g.astype(np.float32, copy=False)
    b = b.astype(np.float32, copy=False)

    height, width = r.shape
    # Create a single-channel mask (L) image
    mask_img = Image.new("L", (width, height), 0)
    draw = ImageDraw.Draw(mask_img)

    font = _choose_font(draw, text, width, height)

    # Measure text size
    if hasattr(draw, "multiline_textbbox"):
        bbox = draw.multiline_textbbox((0, 0), text, font=font)
        text_width = bbox[2] - bbox[0]
        text_height = bbox[3] - bbox[1]
    else:
        text_width, text_height = draw.multiline_textsize(text, font=font)

    # Bottom-right placement with a small margin
    margin_x = int(width * 0.02)
    margin_y = int(height * 0.02)

    x = width - text_width - margin_x
    y = height - text_height - margin_y

    # Clamp to non-negative just in case text is wider than the image
    x = max(margin_x, x)
    y = max(margin_y, y)

    draw.multiline_text((x, y), text, fill=255, font=font)

    # Convert mask to [0,1] float
    mask = np.asarray(mask_img, dtype=np.float32) / 255.0

    # Blend: out = base * (1 - mask) + MAX_VALUE * mask
    r_out = r * (1.0 - mask) + (MAX_VALUE * mask)
    g_out = g * (1.0 - mask) + (MAX_VALUE * mask)
    b_out = b * (1.0 - mask) + (MAX_VALUE * mask)

    return r_out, g_out, b_out


def clip_exr_rgb(
    input_path: str,
    output_path: str,
    overlay_text: Optional[str] = None,
) -> None:
    """
    Read an EXR (R/G/B float32 or float16), clip R/G/B by MAX_VALUE, and
    write out a new EXR.

    Other channels (A, etc.) are copied as-is.

    If overlay_text is not None, it is rendered as bottom-right text onto
    the R/G/B channels (bright text using MAX_VALUE) before writing.
    """
    exr_in = OpenEXR.InputFile(input_path)
    header = exr_in.header()

    # Resolution
    data_window = header["dataWindow"]
    width = data_window.max.x - data_window.min.x + 1
    height = data_window.max.y - data_window.min.y + 1

    float_pt = Imath.PixelType(Imath.PixelType.FLOAT)
    half_pt = Imath.PixelType(Imath.PixelType.HALF)

    required_channels = ["R", "G", "B"]
    channels_info = header["channels"]

    # Verify that R/G/B exist and are FLOAT or HALF
    for ch in required_channels:
        if ch not in channels_info:
            raise ValueError(f"Required channel '{ch}' not found in EXR file.")

        ch_type = channels_info[ch].type
        if ch_type not in (float_pt, half_pt):
            raise TypeError(
                f"Channel '{ch}' is neither float32 nor float16 (HALF). "
                "This script assumes float or half float."
            )

    out_channels: Dict[str, bytes] = {}

    # Store clipped R/G/B as float32 arrays, and remember original pixel types
    rgb_arrays: Dict[str, np.ndarray] = {}
    rgb_types: Dict[str, Imath.PixelType] = {}

    # Read and clip R/G/B
    for ch in required_channels:
        ch_type = channels_info[ch].type

        if ch_type == float_pt:
            np_dtype = np.float32
        else:
            np_dtype = np.float16

        raw = exr_in.channel(ch, pixel_type=ch_type)
        # frombuffer may create a read-only array; copy() to make it writable
        arr = np.frombuffer(raw, dtype=np_dtype).copy()
        arr = arr.reshape((height, width))

        # Convert to float32 for overlay processing
        rgb_arrays[ch] = arr.astype(np.float32)
        rgb_types[ch] = ch_type

    """
    Start of workflow of scene light to target content luminance OOTF
    Emulation workflow:
    1. Open HDRTuner APP and load the EXR image.
    2. There are 3 types of emulation parameters, which are
       EXR metadata, HDRTuner static configuration and algorithm runtime arguments.
       EXR metadata - read from EXR file as emulation tuning panel default value.
       HDRTuner static configuration - default value when running HDRTuner APP.
       Algorithm runtime arguments - Depends on algorithm internal running status.
    3. Emulation tuning panel default parameters.
       ootf_params_metadata - read from EXR file
       ootf_params_static_config - read from HDRTuner
       ootf_params_algorithm - get from algorithm return value when first time running
    4. When emulation operation is applied,
       overlay ootf_params_metadata, ootf_params_static_config and ootf_params_algorithm
       by parameters in emulation tuning panel setting.
       Simultaneously, set the emulation_status argument of alt_image_ref_ootf() to True.
       Note: when HDRTuner runs first time or before HDRTuner get the default value,
       don't set the emulation_status to True.
    """

    # Read exr metadata
    if "adrcGain" in header:
        adrc_gain = header["adrcGain"]
    else:
        adrc_gain = 1.0
    if 'hdrRefWhite' in header:
        hdr_ref_white_luminance = header["hdrRefWhite"]
    else:
        hdr_ref_white_luminance = HDR_REF_WHITE_LUMINANCE
    if 'hdrRatio' in header:
        hdr_ratio = header["hdrRatio"]
    else:
        hdr_ratio = 1.0
    if "gamut" in header:
        gamut = header["gamut"]
    else:
        # TODO: Use HDRTuner parameter "Settings -> Color Space"
        # Here use sRGB as default
        gamut = CICP_COLOR_PRIMARIES_SRGB

    # OOTF emulation tuning parameters

    # EXR metadata
    ootf_params_metadata: Dict[str, Any] = {
        "Captured ADRC Gain": adrc_gain,
        "Captured HDR Ratio": hdr_ratio,
        "Captured Gamut": gamut,  # Only support sRGB, P3 and BT.2020
        "HDR Ref White Luminance (nits)": hdr_ref_white_luminance
    }

    # Static configuration
    ootf_params_static_config: Dict[str, Any] = {
        "Captured EV Max": CAPTURED_MAX_EV,
        "Content Target Luminance Max (nits)": CONTENT_TARGET_LUMINANCE_MAX,
        "EXR Ref White Luminance (nits)": EXR_REF_WHITE_LUMINANCE,
        "Scene Light Clip Low Percent (%)": SCENE_LIGHT_CLIP_LOW_PERCENT,
        "Scene Light Clip High Percent (%)": SCENE_LIGHT_CLIP_HIGH_PERCENT,
        "Ref OOTF Transfer Type (PQ: 16, HLG: 18)": CICP_TRANSFER_CHARACTERISTICS_PQ,
        "Display Light Luminance Clip Min (nits)": DISPLAY_LIGHT_LUMINANCE_CLIP_MIN,
        "Display Light Luminance Clip Max (nits)": DISPLAY_LIGHT_LUMINANCE_CLIP_MAX,
        "TC Data Type (L: 0, MaxRGB: 1, Comb: 2)": TONE_CURVE_DATA_TYPE_COMB_DENSITY,
    }

    # Algorithm runtime arguments
    ootf_params_algo_runtime_args = {
        "Scene Light HDR Ratio": 3.0,
        "Ntw (Norm Target Ref White)": 1.0,
        "Nt (Norm Target Dynamic Range)": 5.0,
        "Ns (Norm Scene Dynamic Range)": 5.0,
    }

    # Get rgb_in data from exr rgb
    rgb_in = np.dstack((rgb_arrays["R"], rgb_arrays["G"], rgb_arrays["B"]))

    # Process input linear rgb by reference ootf to get content target luminance
    norm_rgb_out, output_algo_runtime_args = alt_image_ref_ootf(rgb_in,
                                                                ootf_params_metadata,
                                                                ootf_params_static_config,
                                                                ootf_params_algo_runtime_args,
                                                                emulation_status=False)

    print("output_algo_runtime_args:")
    print(output_algo_runtime_args)

    # Copy output rgb to rgb_arrays
    rgb_arrays["R"] = norm_rgb_out[:, :, 0]
    rgb_arrays["G"] = norm_rgb_out[:, :, 1]
    rgb_arrays["B"] = norm_rgb_out[:, :, 2]

    """
    End of workflow of scene light to target content luminance OOTF
    """

    # If overlay_text is given, apply it to R/G/B
    if overlay_text is not None:
        r_arr, g_arr, b_arr = (
            rgb_arrays["R"],
            rgb_arrays["G"],
            rgb_arrays["B"],
        )
        r_arr, g_arr, b_arr = overlay_text_on_rgb_channels(
            r_arr,
            g_arr,
            b_arr,
            overlay_text,
        )
        rgb_arrays["R"] = r_arr
        rgb_arrays["G"] = g_arr
        rgb_arrays["B"] = b_arr

    # Now pack R/G/B back into bytes with original pixel types
    for ch in required_channels:
        ch_type = rgb_types[ch]
        arr = rgb_arrays[ch]

        if ch_type == float_pt:
            out_channels[ch] = arr.astype(np.float32).tobytes()
        else:
            out_channels[ch] = arr.astype(np.float16).tobytes()

    # Copy other channels (e.g., A) as-is
    for ch_name, ch_info in channels_info.items():
        if ch_name in required_channels:
            continue
        raw = exr_in.channel(ch_name, pixel_type=ch_info.type)
        out_channels[ch_name] = raw

    # Write output EXR, reusing the original header
    exr_out = OpenEXR.OutputFile(output_path, header)
    exr_out.writePixels(out_channels)

    exr_in.close()
    exr_out.close()


def main(argv: List[str]) -> int:
    """
    Command line entry point.

    :param argv: sys.argv (argv[0] is the script name)
    :return: exit code (0: success, non-zero: error)
    """
    if len(argv) < 3:
        print(
            "Usage: python clip_exr_rgb.py "
            "<input.exr> <output.exr> [metadata.json]",
            file=sys.stderr,
        )
        return 1

    input_path = argv[1]
    output_path = argv[2]

    overlay_text: Optional[str] = None

    if len(argv) >= 4:
        json_path = argv[3]
        try:
            with open(json_path, "r", encoding="utf-8") as f:
                meta_obj = json.load(f)
            if not isinstance(meta_obj, dict):
                raise ValueError(
                    "Metadata JSON must be an object (name->value)."
                )
            overlay_text = format_metadata_for_overlay(meta_obj)
            overlay_text = None
        except Exception as exc:
            print(f"Error while reading metadata JSON: {exc}", file=sys.stderr)
            return 1

    try:
        clip_exr_rgb(input_path, output_path, overlay_text=overlay_text)
    except Exception as exc:
        print(f"Error while processing EXR: {exc}", file=sys.stderr)
        return 1

    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
