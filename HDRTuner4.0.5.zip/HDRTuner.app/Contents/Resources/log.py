################################################################
# Copyright (c) 2026 Honor Device Co., Ltd. All rights reserved.
#
# Hardware Engineering Dept.
# Display Platform Technologies Dept.
#
# Author: Ding Yue 00012140 <dingyue2@honor.com>
################################################################


# Log module

def log(level, *args):
    message = ' '.join(map(str, args))
    if level == 'INFO':
        print(f"-I {message}")
    elif level == 'WARNING':
        print(f"-W {message}")
    elif level == 'ERROR':
        print(f"-E {message}")
    elif level == 'DEBUG':
        print(f"-D {message}")
    else:
        pass

def LOG_I(*args): log('INFO', *args)

def LOG_W(*args): log('WARNING', *args)

def LOG_E(*args): log('ERROR', *args)

def LOG_D(*args): log('', *args)
