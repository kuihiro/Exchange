#!/usr/bin/env python3
"""
exr_hdr_to_sdr_tiff.py

Reads a float EXR file (HDR, R/G/B) and:

 1. Applies tone mapping to convert HDR to SDR (around 0.0–1.0),
 2. Normalizes so that the maximum scene luminance Y becomes 1.0,
 3. Applies the sRGB OETF,
 4. Writes an 8-bit RGB TIFF.

This is intended as a minimal reference pipeline for UltraHDR-like use
cases.

The goal of this script is to illustrate the overall flow:
 read HDR EXR -> tone map & normalize -> apply OETF -> write 8-bit TIFF.

The tone mapping itself is just a reference implementation and is
designed to be easy to swap out. UltraHDR typically supports sRGB / P3 /
BT.2020, but here we assume that the OETF is always the sRGB transfer.

Usage:
  python exr_hdr_to_sdr_tiff.py input.exr output.tiff meta.json

Assumptions:
  - The input EXR has at least "R", "G", "B" channels.
  - Channels are float32 or float16 (HALF).
  - Other channels (A, etc.) are ignored.
"""

import sys
import json
from typing import List, Tuple, Optional, Dict, Any

import numpy as np
import OpenEXR
import Imath
from PIL import Image, ImageDraw, ImageFont


def read_exr_rgb_float32(path: str) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """
    Read R, G, B channels from an EXR file.

    Channel types can be float32 (FLOAT) or float16 (HALF). The returned arrays
    are converted to float32 for downstream processing.

    :return: (R, G, B) each with shape=(H, W), dtype=float32
    """
    exr_in = OpenEXR.InputFile(path)
    header = exr_in.header()

    # Resolution
    dw = header["dataWindow"]
    width = dw.max.x - dw.min.x + 1
    height = dw.max.y - dw.min.y + 1

    float_pt = Imath.PixelType(Imath.PixelType.FLOAT)
    half_pt = Imath.PixelType(Imath.PixelType.HALF)

    channels_info = header["channels"]

    # Verify that R/G/B exist and are FLOAT or HALF
    for ch in ["R", "G", "B"]:
        if ch not in channels_info:
            raise ValueError(f"Required channel '{ch}' not found in EXR file.")

        ch_type = channels_info[ch].type
        if ch_type not in (float_pt, half_pt):
            raise TypeError(
                f"Channel '{ch}' is neither float32 nor float16 (HALF). "
                "This script assumes float or half float."
            )

    def read_channel(name: str) -> np.ndarray:
        ch_type = channels_info[name].type
        if ch_type == float_pt:
            pixel_type = float_pt
            np_dtype = np.float32
        else:
            pixel_type = half_pt
            np_dtype = np.float16

        raw = exr_in.channel(name, pixel_type=pixel_type)
        # frombuffer may create a read-only array; copy() to get a writable
        # buffer
        arr = np.frombuffer(raw, dtype=np_dtype).copy()
        arr = arr.reshape((height, width))
        # Convert to float32 for subsequent processing
        return arr.astype(np.float32)

    r = read_channel("R")
    g = read_channel("G")
    b = read_channel("B")

    exr_in.close()
    return r, g, b


def tone_map(
    r: np.ndarray, g: np.ndarray, b: np.ndarray
) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """
    Apply tone mapping to HDR RGB (0..∞) and normalize so that the maximum
    luminance Y in the image becomes 1.0.

    Steps:

    1) Tone mapping:
      - Uses a global Reinhard tone mapping operator as a reference.
      - Negative values are clipped to 0 and treated as noise.
      - Luminance-based compression.

    2) Normalization:
      - Luminance is defined as:
        Y = 0.2126 * R + 0.7152 * G + 0.0722 * B
      - Output is scaled so that the maximum Y becomes 1.0.

    If you want to try a different tone mapping algorithm, replace the body
    of this function while keeping its signature.
    """
    eps = 1e-6

    # 1. Reinhard tone mapping
    # Input HDR may contain negative values, but we ignore negative luminance
    # and clip them to 0 here.
    r_lin = np.maximum(r, 0.0)
    g_lin = np.maximum(g, 0.0)
    b_lin = np.maximum(b, 0.0)

    # Luminance (using Rec.709/sRGB coefficients)
    y = 0.2126 * r_lin + 0.7152 * g_lin + 0.0722 * b_lin

    # Log-average luminance
    y_safe = np.maximum(y, eps)
    log_avg = np.exp(np.mean(np.log(y_safe)))

    # Reinhard key value
    a = 0.018

    # Normalized luminance
    y_m = (a / log_avg) * y
    y_d = y_m / (1.0 + y_m)  # in [0, 1)

    # Scale RGB by luminance ratio to preserve chromaticity
    scale = y_d / (y + eps)

    r_sdr = np.clip(r_lin * scale, 0.0, 1.0)
    g_sdr = np.clip(g_lin * scale, 0.0, 1.0)
    b_sdr = np.clip(b_lin * scale, 0.0, 1.0)

    # 2. Normalize so that max luminance is 1.0
    y_sdr = 0.2126 * r_sdr + 0.7152 * g_sdr + 0.0722 * b_sdr
    y_max = float(y_sdr.max())

    if y_max < eps:
        # Completely black or numerically close to zero
        return r_sdr, g_sdr, b_sdr

    scale_max = 1.0 / y_max
    r_out = r_sdr * scale_max
    g_out = g_sdr * scale_max
    b_out = b_sdr * scale_max

    return r_out, g_out, b_out


def apply_srgb_oetf(linear_rgb: np.ndarray) -> np.ndarray:
    """
    Apply the sRGB OETF to linear [0,1] RGB, returning non-linear sRGB [0,1].

    OETF:
      if C <= 0.0031308: C' = 12.92 * C
      else:              C' = 1.055 * C^(1/2.4) - 0.055

    For UltraHDR scenarios with sRGB / P3 / BT.2020, we assume the same
    sRGB transfer function is used as the OETF.
    """
    c = np.clip(linear_rgb, 0.0, 1.0)
    threshold = 0.0031308

    low = c <= threshold
    high = ~low

    c_out = np.empty_like(c, dtype=np.float32)
    c_out[low] = 12.92 * c[low]
    c_out[high] = 1.055 * np.power(c[high], 1.0 / 2.4) - 0.055

    return np.clip(c_out, 0.0, 1.0)


def format_metadata_for_overlay(meta: Dict[str, Any]) -> str:
    """
    Format metadata dict (name -> value) as a multi-line string suitable
    for overlay.

    - If value is int/float: format with up to 4 decimal places.
    - Otherwise: str(value).
    - Keys are processed in the insertion order, which corresponds to
      the order in the JSON file (for Python 3.7+).
    """
    lines: List[str] = []

    # ★ここで順番を保持する：sorted(...) をやめてそのまま items() を使う
    for key, value in meta.items():
        if isinstance(value, (int, float)):
            # Format with up to 4 decimal places, strip trailing zeros
            formatted = f"{value:.4f}".rstrip("0").rstrip(".")
        else:
            formatted = str(value)
        lines.append(f"{key}: {formatted}")

    return "\n".join(lines)



def overlay_text_on_image(img: Image.Image, text: str) -> Image.Image:
    """
    Overlay the given text (possibly multi-line) on the provided image.

    Currently:
      - Tries to choose a font size so that the text width is about half
        of the image width (but not exceeding it).
      - Draws white text near the top-left.
      - Falls back to the default PIL font if TrueType font loading fails.
    """
    draw = ImageDraw.Draw(img)
    img_width, img_height = img.size
    target_fraction = 0.5  # target: text width ≈ 1/2 of image width
    target_width = img_width * target_fraction

    font = None

    def measure_text_size(font_obj: ImageFont.FreeTypeFont) -> Tuple[int, int]:
        # Try multiline_textbbox (newer Pillow) first, then multiline_textsize.
        if hasattr(draw, "multiline_textbbox"):
            bbox = draw.multiline_textbbox((0, 0), text, font=font_obj)
            width = bbox[2] - bbox[0]
            height = bbox[3] - bbox[1]
        else:
            width, height = draw.multiline_textsize(text, font=font_obj)
        return width, height

    try:
        # Try some common TrueType font paths.
        font_path_candidates = [
            "DejaVuSans.ttf",
            "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
            "/Library/Fonts/Arial.ttf",
            "Arial.ttf",
        ]

        base_font_path = None
        for path in font_path_candidates:
            try:
                _ = ImageFont.truetype(path, size=10)
                base_font_path = path
                break
            except Exception:
                continue

        if base_font_path is None:
            raise RuntimeError("No suitable TrueType font found")

        font_size = 10
        font = ImageFont.truetype(base_font_path, size=font_size)
        text_width, _ = measure_text_size(font)

        # Increase font size until we approach target_width
        while text_width < target_width and font_size < 300:
            font_size += 2
            font = ImageFont.truetype(base_font_path, size=font_size)
            text_width, _ = measure_text_size(font)

        # If we overshot, step back once
        if text_width > target_width and font_size > 10:
            font_size -= 2
            font = ImageFont.truetype(base_font_path, size=font_size)

    except Exception:
        # Fallback to default font
        font = ImageFont.load_default()

    margin_x = int(img_width * 0.02)  # 2% left margin
    margin_y = int(img_height * 0.02)  # 2% top margin

    draw.multiline_text(
        (margin_x, margin_y),
        text,
        fill=(255, 255, 255),
        font=font,
    )
    return img


def save_as_tiff_8bit(
    r: np.ndarray,
    g: np.ndarray,
    b: np.ndarray,
    path: str,
    overlay_text: Optional[str],
) -> None:
    """
    Quantize OETF-applied [0,1] R/G/B to 8-bit (0–255) and save as a TIFF file.

    If overlay_text is not None, the text is superimposed on the image
    before saving (for debug/verification purposes).
    """
    # Extra safety: clip again to [0,1]
    r = np.clip(r, 0.0, 1.0)
    g = np.clip(g, 0.0, 1.0)
    b = np.clip(b, 0.0, 1.0)

    r8 = (r * 255.0 + 0.5).astype(np.uint8)
    g8 = (g * 255.0 + 0.5).astype(np.uint8)
    b8 = (b * 255.0 + 0.5).astype(np.uint8)

    rgb8 = np.stack([r8, g8, b8], axis=-1)  # (H, W, 3)

    img = Image.fromarray(rgb8, mode="RGB")

    if overlay_text is not None:
        img = overlay_text_on_image(img, overlay_text)

    img.save(path, format="TIFF")


def main(argv: List[str]) -> int:
    # 使い方:
    #   python exr_hdr_to_sdr_tiff.py input.exr output.tiff [metadata.json]
    #
    # - 引数 3 個: JSON 付き (Emulate モード相当)
    # - 引数 2 個: JSON なし (Normal モード相当)
    if len(argv) < 3:
        print(
            "Usage: python exr_hdr_to_sdr_tiff.py "
            "<input.exr> <output.tiff> [metadata.json]",
            file=sys.stderr,
        )
        return 1

    input_exr = argv[1]
    output_tiff = argv[2]

    # JSON があるかどうかを判定
    json_path: Optional[str] = None
    if len(argv) >= 4:
        json_path = argv[3]

    try:
        overlay_text: Optional[str] = None

        # 0. JSON があれば読み込んで overlay 用文字列を作る
        if json_path is not None:
            with open(json_path, "r", encoding="utf-8") as f:
                meta_obj = json.load(f)

            if not isinstance(meta_obj, dict):
                raise ValueError("Metadata JSON must be an object (name->value).")

            overlay_text = format_metadata_for_overlay(meta_obj)
        else:
            # JSON がなければ overlay は行わない
            overlay_text = None

        # 1. HDR EXR (R/G/B as float32) 読み込み
        r, g, b = read_exr_rgb_float32(input_exr)

        # 2. トーンマッピング + 最大輝度正規化
        r_sdr, g_sdr, b_sdr = tone_map(r, g, b)

        # 3. sRGB OETF 適用 (linear -> non-linear)
        r_nl = apply_srgb_oetf(r_sdr)
        g_nl = apply_srgb_oetf(g_sdr)
        b_nl = apply_srgb_oetf(b_sdr)

        # 4. 8-bit TIFF 書き出し（overlay_text が None のときは重畳なし）
        save_as_tiff_8bit(r_nl, g_nl, b_nl, output_tiff, overlay_text=overlay_text)

    except Exception as exc:
        print(f"Error: {exc}", file=sys.stderr)
        return 1

    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
