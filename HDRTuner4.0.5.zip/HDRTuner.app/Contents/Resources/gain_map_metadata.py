################################################################
# Copyright (c) 2026 Honor Device Co., Ltd. All rights reserved.
#
# Hardware Engineering Dept.
# Display Platform Technologies Dept.
#
# Author: Ding Yue 00012140 <dingyue2@honor.com>
################################################################


import struct
from log import *


# def LOG_D(*args): log('DEBUG', *args)


##################################################
########### Gain Map Metadata Definition #########
##################################################

# Refer to ISO 21496-1:2025

# Big endian mode for gain map metadata payload
GAIN_MAP_QUANTIZATION_JPEG = 8
GAIN_MAP_IS_MULTICHANNEL_BIT = 7
GAIN_MAP_USE_BASE_COLOUR_SPACE_BIT = 6
GAIN_MAP_IS_MULTICHANNEL_MASK = (1 << GAIN_MAP_IS_MULTICHANNEL_BIT)
GAIN_MAP_USE_BASE_COLOUR_SPACE_MASK = (1 << GAIN_MAP_USE_BASE_COLOUR_SPACE_BIT)


##################################################
################ Class Definition ################
##################################################

# Single channel gain map parameters
class GainMapMetadataScParam(object):

    def __init__(self):

        self.base_hdr_headroom = 0.0
        self.alternate_hdr_headroom = 1.0
        self.gain_map_min = 0.0
        self.gain_map_max = 1.0
        self.gamma = 1.0
        self.base_offset = 0.000001
        self.alternate_offset = 0.000001


# Single channel gain map
class GainMapMetadataSc(object):

    def __init__(self):

        self.minimum_version = 0                          # uint(16)
        self.writer_version = 0                           # uint(16)
        self.is_multichannel = 0                          # uint(1)
        self.use_base_colour_space = 1                    # uint(1)
        self.reserved = 0                                 # uint(6)
        self.base_hdr_headroom_numerator = 0              # uint(32)
        self.base_hdr_headroom_denominator = 1000000      # uint(32)
        self.alternate_hdr_headroom_numerator = 1000000   # uint(32)
        self.alternate_hdr_headroom_denominator = 1000000 # uint(32)
        self.gain_map_min_numerator = 0                   # int(32)
        self.gain_map_min_denominator = 1000000           # uint(32)
        self.gain_map_max_numerator = 1000000             # int(32)
        self.gain_map_max_denominator = 1000000           # uint(32)
        self.gamma_numerator = 1000000                    # uint(32)
        self.gamma_denominator = 1000000                  # uint(32)
        self.base_offset_numerator = 1                    # int(32)
        self.base_offset_denominator = 1000000            # uint(32)
        self.alternate_offset_numerator = 1               # int(32)
        self.alternate_offset_denominator = 1000000       # uint(32)


    def show(self) -> None:

        LOG_I("Gain map metadata single channel:")

        for key, value in vars(self).items():
            LOG_I(key + ": " + str(value))


    def get_params(self) -> GainMapMetadataScParam:

        gain_map_md_param = GainMapMetadataScParam()
        gain_map_md_param.base_hdr_headroom = \
                float(self.base_hdr_headroom_numerator / self.base_hdr_headroom_denominator)
        gain_map_md_param.alternate_hdr_headroom = \
                float(self.alternate_hdr_headroom_numerator / self.alternate_hdr_headroom_denominator)
        gain_map_md_param.gain_map_min = \
                float(self.gain_map_min_numerator / self.gain_map_min_denominator)
        gain_map_md_param.gain_map_max = \
                float(self.gain_map_max_numerator / self.gain_map_max_denominator)
        gain_map_md_param.gamma = \
                float(self.gamma_numerator / self.gamma_denominator)
        gain_map_md_param.base_offset = \
                float(self.base_offset_numerator / self.base_offset_denominator)
        gain_map_md_param.alternate_offset = \
                float(self.alternate_offset_numerator / self.alternate_offset_denominator)

        return gain_map_md_param


    def show_params(self) -> None:

        LOG_I("Gain map metadata single channel parameters:")
        gain_map_md_param = self.get_params()
        LOG_I("base_hdr_headroom = %f" % gain_map_md_param.base_hdr_headroom)
        LOG_I("alternate_hdr_headroom = %f" % gain_map_md_param.alternate_hdr_headroom)
        LOG_I("gain_map_min = %f" % gain_map_md_param.gain_map_min)
        LOG_I("gain_map_max = %f" % gain_map_md_param.gain_map_max)
        LOG_I("gamma = %f" % gain_map_md_param.gamma)
        LOG_I("base_offset = %f" % gain_map_md_param.base_offset)
        LOG_I("alternate_offset = %f" % gain_map_md_param.alternate_offset)


    def pack(self) -> bytes:

        # B: unsigned int(8)
        # b: int(8)
        # I: unsigned int(32)
        # i: int(32)
        # H: unsigned int(16)
        # h: int(16)
        # = original byte order, > big endian byte order, < little endian byte order
        packed_metadata = struct.pack(">HHBIIIIiIiIIIiIiI",
                                      self.minimum_version,
                                      self.writer_version,
                                      (self.is_multichannel << GAIN_MAP_IS_MULTICHANNEL_BIT) |
                                      (self.use_base_colour_space << GAIN_MAP_USE_BASE_COLOUR_SPACE_BIT),
                                      self.base_hdr_headroom_numerator,
                                      self.base_hdr_headroom_denominator,
                                      self.alternate_hdr_headroom_numerator,
                                      self.alternate_hdr_headroom_denominator,
                                      self.gain_map_min_numerator,
                                      self.gain_map_min_denominator,
                                      self.gain_map_max_numerator,
                                      self.gain_map_max_denominator,
                                      self.gamma_numerator,
                                      self.gamma_denominator,
                                      self.base_offset_numerator,
                                      self.base_offset_denominator,
                                      self.alternate_offset_numerator,
                                      self.alternate_offset_denominator)

        return packed_metadata


    def unpack(self, gain_map_md_binary: bytes) -> 'GainMapMetadataSc':

        unpacked_metadata = GainMapMetadataSc()
        unpacked_metadata.minimum_version, = struct.unpack('>H', gain_map_md_binary[0: 2])
        unpacked_metadata.writer_version, = struct.unpack('>H', gain_map_md_binary[2: 4])
        unpacked_metadata.is_multichannel = (gain_map_md_binary[4] & GAIN_MAP_IS_MULTICHANNEL_MASK) \
                                            >> GAIN_MAP_IS_MULTICHANNEL_BIT
        unpacked_metadata.use_base_colour_space = (gain_map_md_binary[4] & GAIN_MAP_USE_BASE_COLOUR_SPACE_MASK) \
                                                  >> GAIN_MAP_USE_BASE_COLOUR_SPACE_BIT
        unpacked_metadata.base_hdr_headroom_numerator, = struct.unpack('>I', gain_map_md_binary[5: 9])
        unpacked_metadata.base_hdr_headroom_denominator, = struct.unpack('>I', gain_map_md_binary[9: 13])
        unpacked_metadata.alternate_hdr_headroom_numerator, = struct.unpack('>I', gain_map_md_binary[13: 17])
        unpacked_metadata.alternate_hdr_headroom_denominator, = struct.unpack('>I', gain_map_md_binary[17: 21])
        unpacked_metadata.gain_map_min_numerator, = struct.unpack('>i', gain_map_md_binary[21: 25])
        unpacked_metadata.gain_map_min_denominator, = struct.unpack('>I', gain_map_md_binary[25: 29])
        unpacked_metadata.gain_map_max_numerator, = struct.unpack('>i', gain_map_md_binary[29: 33])
        unpacked_metadata.gain_map_max_denominator, = struct.unpack('>I', gain_map_md_binary[33: 37])
        unpacked_metadata.gamma_numerator, = struct.unpack('>I', gain_map_md_binary[37: 41])
        unpacked_metadata.gamma_denominator, = struct.unpack('>I', gain_map_md_binary[41: 45])
        unpacked_metadata.base_offset_numerator, = struct.unpack('>I', gain_map_md_binary[45: 49])
        unpacked_metadata.base_offset_denominator, = struct.unpack('>I', gain_map_md_binary[49: 53])
        unpacked_metadata.alternate_offset_numerator, = struct.unpack('>I', gain_map_md_binary[53: 57])
        unpacked_metadata.alternate_offset_denominator, = struct.unpack('>I', gain_map_md_binary[57: 61])

        return unpacked_metadata


    def get_quantization(self) -> int:

        return GAIN_MAP_QUANTIZATION_JPEG


# Multi channel gain map parameters
class GainMapMetadataMcParam(object):

    def __init__(self):

        self.base_hdr_headroom = 0.0
        self.alternate_hdr_headroom = 1.0
        self.gain_map_min_rc = 0.0
        self.gain_map_max_rc = 1.0
        self.gamma_rc = 1.0
        self.base_offset_rc = 0.000001
        self.alternate_offset_rc = 0.000001
        self.gain_map_min_gc = 0.0
        self.gain_map_max_gc = 1.0
        self.gamma_gc = 1.0
        self.base_offset_gc = 0.000001
        self.alternate_offset_gc = 0.000001
        self.gain_map_min_bc = 0.0
        self.gain_map_max_bc = 1.0
        self.gamma_bc = 1.0
        self.base_offset_bc = 0.000001
        self.alternate_offset_bc = 0.000001


# Multi channel gain map metadata
class GainMapMetadataMc(object):

    def __init__(self):

        self.minimum_version = 0                          # uint(16)
        self.writer_version = 0                           # uint(16)
        self.is_multichannel = 1                          # uint(1)
        self.use_base_colour_space = 0                    # uint(1)
        self.reserved = 0                                 # uint(6)
        self.base_hdr_headroom_numerator = 0              # uint(32)
        self.base_hdr_headroom_denominator = 1000000      # uint(32)
        self.alternate_hdr_headroom_numerator = 1000000   # uint(32)
        self.alternate_hdr_headroom_denominator = 1000000 # uint(32)
        self.gain_map_min_rc_numerator = 0                # int(32)
        self.gain_map_min_rc_denominator = 1000000        # uint(32)
        self.gain_map_max_rc_numerator = 1000000          # int(32)
        self.gain_map_max_rc_denominator = 1000000        # uint(32)
        self.gamma_rc_numerator = 1000000                 # uint(32)
        self.gamma_rc_denominator = 1000000               # uint(32)
        self.base_offset_rc_numerator = 1                 # int(32)
        self.base_offset_rc_denominator = 1000000         # uint(32)
        self.alternate_offset_rc_numerator = 1            # int(32)
        self.alternate_offset_rc_denominator = 1000000    # uint(32)
        self.gain_map_min_gc_numerator = 0                # int(32)
        self.gain_map_min_gc_denominator = 1000000        # uint(32)
        self.gain_map_max_gc_numerator = 1000000          # int(32)
        self.gain_map_max_gc_denominator = 1000000        # uint(32)
        self.gamma_gc_numerator = 1000000                 # uint(32)
        self.gamma_gc_denominator = 1000000               # uint(32)
        self.base_offset_gc_numerator = 1                 # int(32)
        self.base_offset_gc_denominator = 1000000         # uint(32)
        self.alternate_offset_gc_numerator = 1            # int(32)
        self.alternate_offset_gc_denominator = 1000000    # uint(32)
        self.gain_map_min_bc_numerator = 0                # int(32)
        self.gain_map_min_bc_denominator = 1000000        # uint(32)
        self.gain_map_max_bc_numerator = 1000000          # int(32)
        self.gain_map_max_bc_denominator = 1000000        # uint(32)
        self.gamma_bc_numerator = 1000000                 # uint(32)
        self.gamma_bc_denominator = 1000000               # uint(32)
        self.base_offset_bc_numerator = 1                 # int(32)
        self.base_offset_bc_denominator = 1000000         # uint(32)
        self.alternate_offset_bc_numerator = 1            # int(32)
        self.alternate_offset_bc_denominator = 1000000    # uint(32)


    def show(self) -> None:

        LOG_I("Gain map metadata multi channel:")

        for key, value in vars(self).items():
            LOG_I(key + ": " + str(value))


    def get_params(self) -> GainMapMetadataMcParam:

        gain_map_md_param = GainMapMetadataMcParam()

        gain_map_md_param.base_hdr_headroom = \
                float(self.base_hdr_headroom_numerator / self.base_hdr_headroom_denominator)
        gain_map_md_param.alternate_hdr_headroom = \
                float(self.alternate_hdr_headroom_numerator / self.alternate_hdr_headroom_denominator)
        gain_map_md_param.gain_map_min_rc = \
                float(self.gain_map_min_rc_numerator / self.gain_map_min_rc_denominator)
        gain_map_md_param.gain_map_max_rc = \
                float(self.gain_map_max_rc_numerator / self.gain_map_max_rc_denominator)
        gain_map_md_param.gamma_rc = \
                float(self.gamma_rc_numerator / self.gamma_rc_denominator)
        gain_map_md_param.base_offset_rc = \
                float(self.base_offset_rc_numerator / self.base_offset_rc_denominator)
        gain_map_md_param.alternate_offset_rc = \
                float(self.alternate_offset_rc_numerator / self.alternate_offset_rc_denominator)
        gain_map_md_param.gain_map_min_gc = \
            float(self.gain_map_min_gc_numerator / self.gain_map_min_gc_denominator)
        gain_map_md_param.gain_map_max_gc = \
            float(self.gain_map_max_gc_numerator / self.gain_map_max_gc_denominator)
        gain_map_md_param.gamma_gc = \
            float(self.gamma_gc_numerator / self.gamma_gc_denominator)
        gain_map_md_param.base_offset_gc = \
            float(self.base_offset_gc_numerator / self.base_offset_gc_denominator)
        gain_map_md_param.alternate_offset_gc = \
            float(self.alternate_offset_gc_numerator / self.alternate_offset_gc_denominator)
        gain_map_md_param.gain_map_min_bc = \
            float(self.gain_map_min_bc_numerator / self.gain_map_min_bc_denominator)
        gain_map_md_param.gain_map_max_bc = \
            float(self.gain_map_max_bc_numerator / self.gain_map_max_bc_denominator)
        gain_map_md_param.gamma_bc = \
            float(self.gamma_bc_numerator / self.gamma_bc_denominator)
        gain_map_md_param.base_offset_bc = \
            float(self.base_offset_bc_numerator / self.base_offset_bc_denominator)
        gain_map_md_param.alternate_offset_bc = \
            float(self.alternate_offset_bc_numerator / self.alternate_offset_bc_denominator)

        return gain_map_md_param


    def show_params(self) -> None:

        LOG_I("Gain map metadata multi channel paramerters:")
        gain_map_md_param = self.get_params()

        LOG_I("base_hdr_headroom = %f" % gain_map_md_param.base_hdr_headroom)
        LOG_I("alternate_hdr_headroom = %f" % gain_map_md_param.alternate_hdr_headroom)
        LOG_I("gain_map_min r, g, b = %f, %f, %f" % \
              (gain_map_md_param.gain_map_min_rc,
               gain_map_md_param.gain_map_min_gc,
               gain_map_md_param.gain_map_min_bc))
        LOG_I("gain_map_max r, g, b = %f, %f, %f" % \
              (gain_map_md_param.gain_map_max_rc,
               gain_map_md_param.gain_map_max_gc,
               gain_map_md_param.gain_map_max_bc))
        LOG_I("gamma r, g, b = %f, %f, %f" % \
              (gain_map_md_param.gamma_rc,
               gain_map_md_param.gamma_gc,
               gain_map_md_param.gamma_bc))
        LOG_I("base_offset r, g, b = %f, %f, %f" % \
              (gain_map_md_param.base_offset_rc,
               gain_map_md_param.base_offset_gc,
               gain_map_md_param.base_offset_bc))
        LOG_I("alternate_offset r, g, b = %f, %f, %f" % \
              (gain_map_md_param.alternate_offset_rc,
               gain_map_md_param.alternate_offset_gc,
               gain_map_md_param.alternate_offset_bc))


    def pack(self) -> bytes:

        # B: unsigned int(8)
        # b: int(8)
        # I: unsigned int(32)
        # i: int(32)
        # H: unsigned int(16)
        # h: int(16)
        # = original byte order, > big endian byte order, < little endian byte order
        packed_metadata = struct.pack(">HHBIIIIiIiIIIiIiIiIiIIIiIiIiIiIIIiIiI",
                                      self.minimum_version,
                                      self.writer_version,
                                      (self.is_multichannel << GAIN_MAP_IS_MULTICHANNEL_BIT) |
                                      (self.use_base_colour_space << GAIN_MAP_USE_BASE_COLOUR_SPACE_BIT),
                                      self.base_hdr_headroom_numerator,
                                      self.base_hdr_headroom_denominator,
                                      self.alternate_hdr_headroom_numerator,
                                      self.alternate_hdr_headroom_denominator,
                                      self.gain_map_min_rc_numerator,
                                      self.gain_map_min_rc_denominator,
                                      self.gain_map_max_rc_numerator,
                                      self.gain_map_max_rc_denominator,
                                      self.gamma_rc_numerator,
                                      self.gamma_rc_denominator,
                                      self.base_offset_rc_numerator,
                                      self.base_offset_rc_denominator,
                                      self.alternate_offset_rc_numerator,
                                      self.alternate_offset_rc_denominator,
                                      self.gain_map_min_gc_numerator,
                                      self.gain_map_min_gc_denominator,
                                      self.gain_map_max_gc_numerator,
                                      self.gain_map_max_gc_denominator,
                                      self.gamma_gc_numerator,
                                      self.gamma_gc_denominator,
                                      self.base_offset_gc_numerator,
                                      self.base_offset_gc_denominator,
                                      self.alternate_offset_gc_numerator,
                                      self.alternate_offset_gc_denominator,
                                      self.gain_map_min_bc_numerator,
                                      self.gain_map_min_bc_denominator,
                                      self.gain_map_max_bc_numerator,
                                      self.gain_map_max_bc_denominator,
                                      self.gamma_bc_numerator,
                                      self.gamma_bc_denominator,
                                      self.base_offset_bc_numerator,
                                      self.base_offset_bc_denominator,
                                      self.alternate_offset_bc_numerator,
                                      self.alternate_offset_bc_denominator)

        return packed_metadata


    def unpack(self, gain_map_md_binary: bytes) -> 'GainMapMetadataMc':

        unpacked_metadata = GainMapMetadataMc()

        unpacked_metadata.minimum_version, = struct.unpack('>H', gain_map_md_binary[0: 2])
        unpacked_metadata.writer_version, = struct.unpack('>H', gain_map_md_binary[2: 4])
        unpacked_metadata.is_multichannel = (gain_map_md_binary[4] & GAIN_MAP_IS_MULTICHANNEL_MASK) \
                                            >> GAIN_MAP_IS_MULTICHANNEL_BIT
        unpacked_metadata.use_base_colour_space = (gain_map_md_binary[4] & GAIN_MAP_USE_BASE_COLOUR_SPACE_MASK) \
                                                  >> GAIN_MAP_USE_BASE_COLOUR_SPACE_BIT
        unpacked_metadata.base_hdr_headroom_numerator, = struct.unpack('>I', gain_map_md_binary[5: 9])
        unpacked_metadata.base_hdr_headroom_denominator, = struct.unpack('>I', gain_map_md_binary[9: 13])
        unpacked_metadata.alternate_hdr_headroom_numerator, = struct.unpack('>I', gain_map_md_binary[13: 17])
        unpacked_metadata.alternate_hdr_headroom_denominator, = struct.unpack('>I', gain_map_md_binary[17: 21])
        unpacked_metadata.gain_map_min_rc_numerator, = struct.unpack('>i', gain_map_md_binary[21: 25])
        unpacked_metadata.gain_map_min_rc_denominator, = struct.unpack('>I', gain_map_md_binary[25: 29])
        unpacked_metadata.gain_map_max_rc_numerator, = struct.unpack('>i', gain_map_md_binary[29: 33])
        unpacked_metadata.gain_map_max_rc_denominator, = struct.unpack('>I', gain_map_md_binary[33: 37])
        unpacked_metadata.gamma_rc_numerator, = struct.unpack('>I', gain_map_md_binary[37: 41])
        unpacked_metadata.gamma_rc_denominator, = struct.unpack('>I', gain_map_md_binary[41: 45])
        unpacked_metadata.base_offset_rc_numerator, = struct.unpack('>I', gain_map_md_binary[45: 49])
        unpacked_metadata.base_offset_rc_denominator, = struct.unpack('>I', gain_map_md_binary[49: 53])
        unpacked_metadata.alternate_offset_rc_numerator, = struct.unpack('>I', gain_map_md_binary[53: 57])
        unpacked_metadata.alternate_offset_rc_denominator, = struct.unpack('>I', gain_map_md_binary[57: 61])
        unpacked_metadata.gain_map_min_gc_numerator, = struct.unpack('>i', gain_map_md_binary[61: 65])
        unpacked_metadata.gain_map_min_gc_denominator, = struct.unpack('>I', gain_map_md_binary[65: 69])
        unpacked_metadata.gain_map_max_gc_numerator, = struct.unpack('>i', gain_map_md_binary[69: 73])
        unpacked_metadata.gain_map_max_gc_denominator, = struct.unpack('>I', gain_map_md_binary[73: 77])
        unpacked_metadata.gamma_gc_numerator, = struct.unpack('>I', gain_map_md_binary[77: 81])
        unpacked_metadata.gamma_gc_denominator, = struct.unpack('>I', gain_map_md_binary[81: 85])
        unpacked_metadata.base_offset_gc_numerator, = struct.unpack('>I', gain_map_md_binary[85: 89])
        unpacked_metadata.base_offset_gc_denominator, = struct.unpack('>I', gain_map_md_binary[89: 93])
        unpacked_metadata.alternate_offset_gc_numerator, = struct.unpack('>I', gain_map_md_binary[93: 97])
        unpacked_metadata.alternate_offset_gc_denominator, = struct.unpack('>I', gain_map_md_binary[97: 101])
        unpacked_metadata.gain_map_min_bc_numerator, = struct.unpack('>i', gain_map_md_binary[101: 105])
        unpacked_metadata.gain_map_min_bc_denominator, = struct.unpack('>I', gain_map_md_binary[105: 109])
        unpacked_metadata.gain_map_max_bc_numerator, = struct.unpack('>i', gain_map_md_binary[109: 113])
        unpacked_metadata.gain_map_max_bc_denominator, = struct.unpack('>I', gain_map_md_binary[113: 117])
        unpacked_metadata.gamma_bc_numerator, = struct.unpack('>I', gain_map_md_binary[117: 121])
        unpacked_metadata.gamma_bc_denominator, = struct.unpack('>I', gain_map_md_binary[121: 125])
        unpacked_metadata.base_offset_bc_numerator, = struct.unpack('>I', gain_map_md_binary[125: 129])
        unpacked_metadata.base_offset_bc_denominator, = struct.unpack('>I', gain_map_md_binary[129: 133])
        unpacked_metadata.alternate_offset_bc_numerator, = struct.unpack('>I', gain_map_md_binary[133: 137])
        unpacked_metadata.alternate_offset_bc_denominator, = struct.unpack('>I', gain_map_md_binary[137: 141])

        return unpacked_metadata


    def get_quantization(self) -> int:

        return GAIN_MAP_QUANTIZATION_JPEG


if __name__ == "__main__":

    LOG_I("Self test gain map metadata...")

